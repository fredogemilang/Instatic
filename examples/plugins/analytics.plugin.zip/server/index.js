(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // examples/plugins/analytics/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    default: () => server_default
  });

  // examples/plugins/analytics/server/ingest.ts
  async function computeVisitorHash(salt, visitorId, date) {
    const input = `${salt}:${visitorId}:${date}`;
    const encoded = new TextEncoder().encode(input);
    const buf = await crypto.subtle.digest("SHA-256", encoded);
    const bytes = new Uint8Array(buf);
    return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  var GLOB_DOUBLE_STAR_SENTINEL = "";
  function matchGlob(path, pattern) {
    const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*\*/g, GLOB_DOUBLE_STAR_SENTINEL).replace(/\*/g, "[^/]*").replace(new RegExp(GLOB_DOUBLE_STAR_SENTINEL, "g"), ".*");
    const re = new RegExp(`^${escaped}$`);
    return re.test(path);
  }
  function isExcludedPath(path, excludePaths) {
    if (!excludePaths.trim())
      return false;
    for (const pattern of excludePaths.split(`
`)) {
      const p = pattern.trim();
      if (p && matchGlob(path, p))
        return true;
    }
    return false;
  }
  function classifyDevice(ua) {
    if (/bot|crawl|spider|slurp|facebookexternalhit|twitterbot/i.test(ua))
      return "bot";
    if (/iPad|Tablet/i.test(ua))
      return "tablet";
    if (/Mobile|Android|iPhone|iPod|Windows Phone/i.test(ua))
      return "mobile";
    return "desktop";
  }
  async function handleTrackerEvent(api, evt) {
    const excludePaths = String(api.cms.settings.get("excludePaths") ?? "");
    const excludeAdmins = Boolean(api.cms.settings.get("excludeAdmins") ?? true);
    const salt = String(api.cms.settings.get("salt") ?? "");
    const path = evt.pagePath ?? "";
    if (path && isExcludedPath(path, excludePaths))
      return;
    if (excludeAdmins && evt.isAdmin === true)
      return;
    const date = evt.receivedAt.slice(0, 10);
    const visitorHash = await computeVisitorHash(salt, evt.visitorId ?? "anon", date);
    const ua = evt.userAgent ?? "";
    const device = ua ? classifyDevice(ua) : "desktop";
    const country = evt.country ?? "";
    const rest = evt.payload;
    const events = api.cms.storage.collection("events");
    await events.create({
      name: evt.eventName,
      path,
      visitorHash,
      session: evt.sessionId ?? "",
      referrer: evt.referrer ?? "",
      device,
      country,
      payload: JSON.stringify(rest),
      receivedAt: evt.receivedAt
    });
  }

  // examples/plugins/analytics/server/rollup.ts
  function topN(map, n = 10) {
    return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, n).map(([label, count]) => ({ label, count }));
  }
  async function runRollup(api) {
    const events = api.cms.storage.collection("events");
    const dailyStats = api.cms.storage.collection("daily-stats");
    const yesterday = new Date;
    yesterday.setUTCDate(yesterday.getUTCDate() - 1);
    const dateStr = yesterday.toISOString().slice(0, 10);
    const dayStart = `${dateStr}T00:00:00.000Z`;
    const dayEnd = `${dateStr}T23:59:59.999Z`;
    const { records: dayEvents } = await events.list({
      filter: { receivedAt: { gte: dayStart, lte: dayEnd } },
      limit: 1000
    });
    if (dayEvents.length === 0)
      return;
    const pageviewEvents = dayEvents.filter((r) => r.data.name === "page-view");
    const pageviews = pageviewEvents.length;
    const visitors = new Set(pageviewEvents.map((r) => String(r.data.visitorHash ?? ""))).size;
    const sessionSet = new Set(dayEvents.map((r) => String(r.data.session ?? "")).filter(Boolean));
    const sessions = sessionSet.size;
    const pageviewsPerSession = new Map;
    for (const r of pageviewEvents) {
      const s = String(r.data.session ?? "");
      if (s)
        pageviewsPerSession.set(s, (pageviewsPerSession.get(s) ?? 0) + 1);
    }
    const bounceSessions = [...pageviewsPerSession.values()].filter((v) => v === 1).length;
    const bounceRate = sessions > 0 ? Math.round(bounceSessions / sessions * 100) : 0;
    const sessionBounds = new Map;
    for (const r of dayEvents) {
      const s = String(r.data.session ?? "");
      if (!s)
        continue;
      const t = new Date(String(r.data.receivedAt ?? r.createdAt)).getTime();
      if (Number.isNaN(t))
        continue;
      const bounds = sessionBounds.get(s);
      if (!bounds)
        sessionBounds.set(s, { min: t, max: t });
      else {
        bounds.min = Math.min(bounds.min, t);
        bounds.max = Math.max(bounds.max, t);
      }
    }
    const durations = [...sessionBounds.values()].map((b) => (b.max - b.min) / 1000);
    const avgSessionSeconds = durations.length > 0 ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length) : 0;
    const pageMap = new Map;
    for (const r of pageviewEvents) {
      const p = String(r.data.path ?? "");
      if (p)
        pageMap.set(p, (pageMap.get(p) ?? 0) + 1);
    }
    const referrerMap = new Map;
    for (const r of pageviewEvents) {
      const ref = String(r.data.referrer ?? "").trim();
      if (ref)
        referrerMap.set(ref, (referrerMap.get(ref) ?? 0) + 1);
    }
    const countryMap = new Map;
    for (const r of dayEvents) {
      const c = String(r.data.country ?? "").trim();
      if (c)
        countryMap.set(c, (countryMap.get(c) ?? 0) + 1);
    }
    const deviceMap = new Map;
    for (const r of dayEvents) {
      const d = String(r.data.device ?? "desktop");
      deviceMap.set(d, (deviceMap.get(d) ?? 0) + 1);
    }
    const payload = {
      date: dateStr,
      pageviews,
      visitors,
      sessions,
      "bounce-rate": bounceRate,
      "avg-session-seconds": avgSessionSeconds,
      "top-pages": JSON.stringify(topN(pageMap)),
      "top-referrers": JSON.stringify(topN(referrerMap)),
      "top-countries": JSON.stringify(topN(countryMap)),
      "top-devices": JSON.stringify(topN(deviceMap))
    };
    const { records: existingRows } = await dailyStats.list({ filter: { date: dateStr } });
    if (existingRows[0]) {
      await dailyStats.update(existingRows[0].id, payload);
    } else {
      await dailyStats.create(payload);
    }
  }
  async function runPrune(api) {
    const retentionDays = Number(api.cms.settings.get("retentionDays") ?? 90);
    const cutoffMs = Date.now() - retentionDays * 86400000;
    const cutoffIso = new Date(cutoffMs).toISOString();
    const events = api.cms.storage.collection("events");
    const { records: stale } = await events.list({
      filter: { receivedAt: { lt: cutoffIso } },
      limit: 1000
    });
    for (const r of stale) {
      await events.delete(r.id);
    }
    if (stale.length > 0) {
      api.plugin.log(`[analytics] pruned ${stale.length} events older than ${retentionDays} days`);
    }
  }

  // examples/plugins/analytics/server/stats.ts
  function todayUtc() {
    return new Date().toISOString().slice(0, 10);
  }
  function addDays(dateStr, days) {
    const d = new Date(dateStr + "T00:00:00Z");
    d.setUTCDate(d.getUTCDate() + days);
    return d.toISOString().slice(0, 10);
  }
  function subtractDays(dateStr, days) {
    return addDays(dateStr, -days);
  }
  function resolveRange(range) {
    const today = todayUtc();
    if (typeof range === "string") {
      const days2 = range === "1d" ? 1 : range === "7d" ? 7 : range === "30d" ? 30 : 90;
      return {
        from: subtractDays(today, days2 - 1),
        to: today,
        days: days2
      };
    }
    const msFrom = new Date(range.from + "T00:00:00Z").getTime();
    const msTo = new Date(range.to + "T00:00:00Z").getTime();
    const days = Math.round((msTo - msFrom) / 86400000) + 1;
    return { from: range.from, to: range.to, days };
  }
  function inRange(dateStr, from, to) {
    return dateStr >= from && dateStr <= to;
  }
  function mergeTopJsonFields(records, field) {
    const merged = new Map;
    for (const r of records) {
      const raw = r.data[field];
      if (typeof raw !== "string")
        continue;
      try {
        const entries = JSON.parse(raw);
        if (!Array.isArray(entries))
          continue;
        for (const e of entries) {
          if (typeof e.label === "string" && typeof e.count === "number") {
            merged.set(e.label, (merged.get(e.label) ?? 0) + e.count);
          }
        }
      } catch {}
    }
    return merged;
  }
  function mapToTopEntries(map, total, n = 10) {
    return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, n).map(([label, count]) => ({
      label,
      count,
      pct: total > 0 ? Math.round(count / total * 100) : 0
    }));
  }
  function aggregateLiveEvents(events, from, to) {
    const agg = {
      pageviews: 0,
      visitors: 0,
      sessions: 0,
      bounceSessions: 0,
      topPages: new Map,
      topReferrers: new Map,
      topCountries: new Map,
      topDevices: new Map
    };
    const visitorSet = new Set;
    const sessionSet = new Set;
    const pageviewsPerSession = new Map;
    for (const r of events) {
      const at = String(r.data.receivedAt ?? r.createdAt);
      const dateStr = at.slice(0, 10);
      if (!inRange(dateStr, from, to))
        continue;
      const name = String(r.data.name ?? "");
      const path = String(r.data.path ?? "");
      const session = String(r.data.session ?? "");
      const vh = String(r.data.visitorHash ?? "");
      const referrer = String(r.data.referrer ?? "").trim();
      const country = String(r.data.country ?? "").trim();
      const device = String(r.data.device ?? "desktop");
      if (name === "page-view") {
        agg.pageviews++;
        if (vh)
          visitorSet.add(vh);
        if (session) {
          const prev = pageviewsPerSession.get(session) ?? 0;
          pageviewsPerSession.set(session, prev + 1);
        }
        if (path)
          agg.topPages.set(path, (agg.topPages.get(path) ?? 0) + 1);
        if (referrer)
          agg.topReferrers.set(referrer, (agg.topReferrers.get(referrer) ?? 0) + 1);
      }
      if (session)
        sessionSet.add(session);
      if (country)
        agg.topCountries.set(country, (agg.topCountries.get(country) ?? 0) + 1);
      agg.topDevices.set(device, (agg.topDevices.get(device) ?? 0) + 1);
    }
    agg.visitors = visitorSet.size;
    agg.sessions = sessionSet.size;
    agg.bounceSessions = [...pageviewsPerSession.values()].filter((v) => v === 1).length;
    return agg;
  }
  function deltaPct(current, previous) {
    if (previous === 0)
      return current > 0 ? 100 : 0;
    return Math.round((current - previous) / previous * 100);
  }
  async function getDashboardStats(api, range) {
    const r = resolveRange(range);
    const today = todayUtc();
    const prevFrom = subtractDays(r.from, r.days);
    const prevTo = subtractDays(r.to, r.days);
    const dailyStats = api.cms.storage.collection("daily-stats");
    const events = api.cms.storage.collection("events");
    const [{ records: allStats }, { records: allEvents }] = await Promise.all([
      dailyStats.list({ filter: { date: { gte: prevFrom, lte: r.to } }, limit: 1000 }),
      r.to >= today ? events.list({ filter: { receivedAt: { gte: `${today}T00:00:00.000Z` } }, limit: 1000 }) : Promise.resolve({ records: [], totalCount: 0 })
    ]);
    const curStats = allStats.filter((s) => inRange(String(s.data.date ?? ""), r.from, r.to));
    const prevStats = allStats.filter((s) => inRange(String(s.data.date ?? ""), prevFrom, prevTo));
    function sumStats(rows) {
      let pageviews = 0, visitors = 0, sessions = 0, bounceRateSum = 0;
      for (const r2 of rows) {
        pageviews += Number(r2.data.pageviews ?? 0);
        visitors += Number(r2.data.visitors ?? 0);
        sessions += Number(r2.data.sessions ?? 0);
        bounceRateSum += Number(r2.data["bounce-rate"] ?? 0);
      }
      const bounceRate = rows.length > 0 ? Math.round(bounceRateSum / rows.length) : 0;
      return { pageviews, visitors, sessions, bounceRate };
    }
    const curSumFromStats = sumStats(curStats);
    const prevSum = sumStats(prevStats);
    let curSum = curSumFromStats;
    const liveAgg = r.to >= today ? aggregateLiveEvents(allEvents, today, today) : null;
    if (liveAgg) {
      curSum = {
        pageviews: curSumFromStats.pageviews + liveAgg.pageviews,
        visitors: curSumFromStats.visitors + liveAgg.visitors,
        sessions: curSumFromStats.sessions + liveAgg.sessions,
        bounceRate: liveAgg.sessions > 0 ? Math.round(liveAgg.bounceSessions / liveAgg.sessions * 100) : curSumFromStats.bounceRate
      };
    }
    const statsMap = new Map(curStats.map((s) => [String(s.data.date), Number(s.data.pageviews ?? 0)]));
    if (liveAgg) {
      statsMap.set(today, (statsMap.get(today) ?? 0) + liveAgg.pageviews);
    }
    const series = [];
    let cursor = r.from;
    while (cursor <= r.to) {
      series.push({ date: cursor, pageviews: statsMap.get(cursor) ?? 0 });
      cursor = addDays(cursor, 1);
    }
    const pagesMap = mergeTopJsonFields(curStats, "top-pages");
    const refMap = mergeTopJsonFields(curStats, "top-referrers");
    const countryMap = mergeTopJsonFields(curStats, "top-countries");
    const deviceMap = mergeTopJsonFields(curStats, "top-devices");
    if (liveAgg) {
      for (const [k, v] of liveAgg.topPages)
        pagesMap.set(k, (pagesMap.get(k) ?? 0) + v);
      for (const [k, v] of liveAgg.topReferrers)
        refMap.set(k, (refMap.get(k) ?? 0) + v);
      for (const [k, v] of liveAgg.topCountries)
        countryMap.set(k, (countryMap.get(k) ?? 0) + v);
      for (const [k, v] of liveAgg.topDevices)
        deviceMap.set(k, (deviceMap.get(k) ?? 0) + v);
    }
    const totalPageviews = curSum.pageviews;
    return {
      summary: {
        ...curSum,
        deltaPct: {
          pageviews: deltaPct(curSum.pageviews, prevSum.pageviews),
          visitors: deltaPct(curSum.visitors, prevSum.visitors),
          sessions: deltaPct(curSum.sessions, prevSum.sessions),
          bounceRate: deltaPct(curSum.bounceRate, prevSum.bounceRate)
        }
      },
      series,
      topPages: mapToTopEntries(pagesMap, totalPageviews),
      topReferrers: mapToTopEntries(refMap, totalPageviews),
      topCountries: mapToTopEntries(countryMap, totalPageviews),
      topDevices: mapToTopEntries(deviceMap, totalPageviews)
    };
  }

  // examples/plugins/analytics/server/csv.ts
  function quoteField(value) {
    const s = value == null ? "" : String(value);
    if (s.includes(",") || s.includes('"') || s.includes(`
`) || s.includes("\r")) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  }
  function row(fields) {
    return fields.map(quoteField).join(",");
  }
  function eventsToCsv(records) {
    const header = row(["id", "name", "path", "visitorHash", "session", "referrer", "device", "country", "payload", "receivedAt", "createdAt"]);
    const lines = records.map((r) => row([
      r.id,
      r.data.name,
      r.data.path,
      r.data.visitorHash,
      r.data.session,
      r.data.referrer,
      r.data.device,
      r.data.country,
      r.data.payload,
      r.data.receivedAt,
      r.createdAt
    ]));
    return [header, ...lines].join(`\r
`);
  }
  function dailyStatsToCsv(records) {
    const header = row([
      "date",
      "pageviews",
      "visitors",
      "sessions",
      "bounce-rate",
      "avg-session-seconds",
      "top-pages",
      "top-referrers",
      "top-countries",
      "top-devices"
    ]);
    const lines = records.slice().sort((a, b) => String(a.data.date).localeCompare(String(b.data.date))).map((r) => row([
      r.data.date,
      r.data.pageviews,
      r.data.visitors,
      r.data.sessions,
      r.data["bounce-rate"],
      r.data["avg-session-seconds"],
      r.data["top-pages"],
      r.data["top-referrers"],
      r.data["top-countries"],
      r.data["top-devices"]
    ]));
    return [header, ...lines].join(`\r
`);
  }

  // examples/plugins/analytics/server/index.ts
  function generateSalt() {
    let s = "";
    for (let i = 0;i < 32; i++) {
      s += Math.floor(Math.random() * 16).toString(16);
    }
    return s;
  }
  var mod = {
    install(api) {
      const existing = api.cms.settings.get("salt");
      if (!existing) {
        api.cms.settings.replace({
          ...api.cms.settings.getAll(),
          salt: generateSalt()
        });
      }
      api.plugin.log("[analytics] installed");
    },
    activate(api) {
      api.plugin.log("[analytics] activating");
      const events = api.cms.storage.collection("events");
      const dailyStats = api.cms.storage.collection("daily-stats");
      api.cms.hooks.on("settings.changed", (payload) => {
        if (typeof payload === "object" && payload !== null && "pluginId" in payload && payload.pluginId !== api.plugin.id)
          return;
        api.plugin.log("[analytics] settings updated");
      });
      api.cms.routes.get("/stats", "plugins.read", async (ctx) => {
        const url = new URL(ctx.req.url);
        const rangeParam = url.searchParams.get("range") ?? "7d";
        const validRanges = ["1d", "7d", "30d", "90d"];
        const range = validRanges.includes(rangeParam) ? rangeParam : "7d";
        return getDashboardStats(api, range);
      });
      api.cms.routes.get("/live", "plugins.read", async () => {
        const cutoffIso = new Date(Date.now() - 5 * 60000).toISOString();
        const { records } = await events.list({
          filter: { receivedAt: { gte: cutoffIso } },
          limit: 100
        });
        return { ok: true, events: records.slice(-100).reverse() };
      });
      api.cms.routes.get("/export.csv", "plugins.read", async (ctx) => {
        const url = new URL(ctx.req.url);
        const resource = url.searchParams.get("resource") ?? "events";
        const rangeParam = url.searchParams.get("range") ?? "30d";
        const days = rangeParam === "7d" ? 7 : rangeParam === "30d" ? 30 : rangeParam === "90d" ? 90 : 30;
        const cutoff = new Date(Date.now() - days * 86400000).toISOString();
        let csvBody;
        let filename;
        if (resource === "daily-stats") {
          const { records: rows } = await dailyStats.list({
            filter: { date: { gte: cutoff.slice(0, 10) } },
            limit: 1000
          });
          csvBody = dailyStatsToCsv(rows);
          filename = `analytics-daily-stats-${rangeParam}.csv`;
        } else {
          const { records: filtered } = await events.list({
            filter: { receivedAt: { gte: cutoff } },
            limit: 1000
          });
          csvBody = eventsToCsv(filtered);
          filename = `analytics-events-${rangeParam}.csv`;
        }
        return {
          __response: true,
          status: 200,
          headers: {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": `attachment; filename="${filename}"`
          },
          body: csvBody
        };
      });
      api.cms.routes.public.post("/ingest", async (ctx) => {
        try {
          const body = ctx.body;
          const eventName = typeof body.eventName === "string" ? body.eventName : "";
          if (!eventName) {
            return { __response: true, status: 400, headers: {}, body: '{"error":"missing eventName"}' };
          }
          const payload = body.payload && typeof body.payload === "object" && !Array.isArray(body.payload) ? body.payload : {};
          await handleTrackerEvent(api, {
            eventName,
            payload,
            visitorId: typeof body.visitorId === "string" ? body.visitorId : undefined,
            sessionId: typeof body.sessionId === "string" ? body.sessionId : undefined,
            pagePath: typeof body.pagePath === "string" ? body.pagePath : undefined,
            referrer: typeof body.referrer === "string" ? body.referrer : undefined,
            country: typeof body.country === "string" ? body.country : undefined,
            isAdmin: body.isAdmin === true,
            userAgent: typeof body.userAgent === "string" ? body.userAgent : undefined,
            clientTime: typeof body.clientTime === "string" ? body.clientTime : undefined,
            receivedAt: new Date().toISOString()
          });
          return { ok: true };
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          api.plugin.log("[analytics] ingest failed:", msg);
          return { __response: true, status: 500, headers: {}, body: '{"error":"ingest failed"}' };
        }
      });
      api.cms.routes.public.get("/geo", async (ctx) => {
        const country = ctx.req.headers.get("CF-IPCountry") ?? ctx.req.headers.get("X-Country-Code") ?? "";
        return { country };
      });
      api.cms.routes.public.get("/is-admin", async (ctx) => {
        const cookie = ctx.req.headers.get("cookie") ?? "";
        const admin = cookie.includes("pb_admin_session=");
        return { admin };
      });
      api.cms.routes.public.get("/public-stats.json", async (ctx) => {
        const token = api.cms.settings.get("publicStatsToken") ?? "";
        if (!token) {
          return { __response: true, status: 404, headers: {}, body: '{"error":"disabled"}' };
        }
        const url = new URL(ctx.req.url);
        const provided = url.searchParams.get("token") ?? "";
        if (provided !== token) {
          return { __response: true, status: 403, headers: {}, body: '{"error":"forbidden"}' };
        }
        return getDashboardStats(api, "30d");
      });
      api.cms.schedule.register({
        id: "roll-up",
        cadence: { interval: "daily", at: "02:00" },
        maxDurationMs: 60000,
        overlap: "skip",
        handler: async () => runRollup(api)
      });
      api.cms.schedule.register({
        id: "prune",
        cadence: { interval: "daily", at: "03:00" },
        maxDurationMs: 60000,
        overlap: "skip",
        handler: async () => runPrune(api)
      });
      api.plugin.log("[analytics] activated");
    },
    deactivate(api) {
      api.plugin.log("[analytics] deactivated");
    },
    async uninstall(api) {
      const eventsCol = api.cms.storage.collection("events");
      const statsCol = api.cms.storage.collection("daily-stats");
      let eventsRemoved = 0;
      while (true) {
        const { records, totalCount } = await eventsCol.list({ limit: 1000 });
        if (totalCount === 0 || records.length === 0)
          break;
        await Promise.all(records.map((r) => eventsCol.delete(r.id)));
        eventsRemoved += records.length;
      }
      let statsRemoved = 0;
      while (true) {
        const { records, totalCount } = await statsCol.list({ limit: 1000 });
        if (totalCount === 0 || records.length === 0)
          break;
        await Promise.all(records.map((r) => statsCol.delete(r.id)));
        statsRemoved += records.length;
      }
      api.plugin.log(`[analytics] uninstalled — removed ${eventsRemoved} events, ${statsRemoved} daily-stats rows`);
    }
  };
  var server_default = mod;

  // examples/plugins/analytics/server/__sandbox-facade-1779996241920.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
