// examples/plugins/analytics/editor/index.tsx
import { useEffect, useState } from "react";
import {
  Sparkline,
  StatValue,
  Delta,
  RangeTabs,
  Widget,
  WidgetList,
  WidgetListRow
} from "@pagebuilder/host-ui";

// node_modules/pixel-art-icons/dist/icons/eye-solid.js
import { jsx as _jsx } from "react/jsx-runtime";
function EyeSolidIcon({ size = 24, color = "currentColor", className, style }) {
  return _jsx("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: color, xmlns: "http://www.w3.org/2000/svg", className, style, children: _jsx("path", { d: "M8 18H4v-2H2v-2H0v-4h2V8h2V6h4V4h8v2h4v2h2v2h2v4h-2v2h-2v2h-4v2H8v-2Zm2-8H8v4h2v2h4v-2h2v-4h-2V8h-4v2Zm4 2h-2v-2h2v2Z" }) });
}

// node_modules/pixel-art-icons/dist/icons/star-solid.js
import { jsx as _jsx2 } from "react/jsx-runtime";
function StarSolidIcon({ size = 24, color = "currentColor", className, style }) {
  return _jsx2("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: color, xmlns: "http://www.w3.org/2000/svg", className, style, children: _jsx2("path", { d: "M13 3h2v4h8v4h-2v2h-2v3h2v6h-5v-2h-2v-2h-4v2H8v2H3v-6h2v-3H3v-2H1V7h8V3h2V1h2v2Z" }) });
}

// examples/plugins/analytics/editor/index.tsx
import { jsxDEV, Fragment } from "react/jsx-dev-runtime";
var RANGE_QUERY = {
  "24h": "1d",
  "7d": "7d",
  "30d": "30d"
};
var SINCE_LABEL = {
  "24h": "00:00",
  "7d": "Last 7 days",
  "30d": "Last 30 days"
};
var STATS_URL = "/admin/api/cms/plugins/pagebuilder.analytics/runtime/stats";
function isStatsResponse(value) {
  if (!value || typeof value !== "object")
    return false;
  const v = value;
  if (!v.summary || typeof v.summary !== "object")
    return false;
  if (!Array.isArray(v.series))
    return false;
  if (!Array.isArray(v.topPages))
    return false;
  return true;
}
function useStats(range) {
  const [stats, setStats] = useState(null);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`${STATS_URL}?range=${RANGE_QUERY[range]}`, {
          credentials: "same-origin",
          headers: { Accept: "application/json" }
        });
        if (!res.ok)
          return;
        const data = await res.json();
        if (cancelled)
          return;
        if (isStatsResponse(data))
          setStats(data);
      } catch {}
    })();
    return () => {
      cancelled = true;
    };
  }, [range]);
  return stats;
}
function VisitorsWidget({ span, editing }) {
  const [range, setRange] = useState("7d");
  const stats = useStats(range);
  const series = stats?.series.map((p) => p.pageviews) ?? [0, 0];
  const total = stats?.summary.visitors.toLocaleString() ?? "—";
  const deltaPct = stats?.summary.deltaPct.visitors;
  const deltaLabel = deltaPct === undefined ? null : deltaPct >= 0 ? `+${deltaPct}%` : `${deltaPct}%`;
  return /* @__PURE__ */ jsxDEV(Widget, {
    widgetId: "pagebuilder.analytics.visitors",
    title: "Visitors",
    icon: EyeSolidIcon,
    tint: "mint",
    span,
    editing,
    action: /* @__PURE__ */ jsxDEV(RangeTabs, {
      value: range,
      options: [
        { value: "24h", label: "24h" },
        { value: "7d", label: "7d" },
        { value: "30d", label: "30d" }
      ],
      onChange: setRange,
      ariaLabel: "Visitor range"
    }, undefined, false, undefined, this),
    children: [
      /* @__PURE__ */ jsxDEV(StatValue, {
        value: total,
        delta: deltaLabel ? /* @__PURE__ */ jsxDEV(Delta, {
          children: deltaLabel
        }, undefined, false, undefined, this) : undefined,
        sub: /* @__PURE__ */ jsxDEV("span", {
          children: "Unique visitors · all pages"
        }, undefined, false, undefined, this)
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV("div", {
        style: { marginTop: "auto" },
        children: [
          /* @__PURE__ */ jsxDEV(Sparkline, {
            data: series,
            tint: "var(--rail-tint-mint)",
            height: 68
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV("div", {
            style: {
              display: "flex",
              justifyContent: "space-between",
              fontSize: 11,
              color: "var(--editor-text-muted)",
              fontFamily: "var(--font-mono)",
              marginTop: 6
            },
            children: [
              /* @__PURE__ */ jsxDEV("span", {
                children: SINCE_LABEL[range]
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV("span", {
                children: "Now"
              }, undefined, false, undefined, this)
            ]
          }, undefined, true, undefined, this)
        ]
      }, undefined, true, undefined, this)
    ]
  }, undefined, true, undefined, this);
}
function formatCount(n) {
  return n.toLocaleString();
}
function formatDelta(pct) {
  if (pct === 0)
    return "±0%";
  return pct > 0 ? `+${pct}%` : `${pct}%`;
}
function TopPagesWidget({ span, editing }) {
  const stats = useStats("7d");
  const rows = stats?.topPages.slice(0, 5) ?? [];
  return /* @__PURE__ */ jsxDEV(Widget, {
    widgetId: "pagebuilder.analytics.top-pages",
    title: "Top pages",
    icon: StarSolidIcon,
    tint: "lilac",
    span,
    editing,
    children: /* @__PURE__ */ jsxDEV(WidgetList, {
      children: rows.length === 0 ? /* @__PURE__ */ jsxDEV(WidgetListRow, {
        primary: /* @__PURE__ */ jsxDEV("span", {
          children: "No pages tracked yet"
        }, undefined, false, undefined, this),
        meta: null
      }, undefined, false, undefined, this) : rows.map((row) => /* @__PURE__ */ jsxDEV(WidgetListRow, {
        primary: /* @__PURE__ */ jsxDEV("span", {
          children: row.label
        }, undefined, false, undefined, this),
        meta: /* @__PURE__ */ jsxDEV(Fragment, {
          children: [
            formatCount(row.count),
            /* @__PURE__ */ jsxDEV(Delta, {
              children: formatDelta(row.pct)
            }, undefined, false, undefined, this)
          ]
        }, undefined, true, undefined, this)
      }, row.label, false, undefined, this))
    }, undefined, false, undefined, this)
  }, undefined, false, undefined, this);
}
var mod = {
  activate(api) {
    api.dashboard.widgets.register({
      id: "pagebuilder.analytics.visitors",
      name: "Visitors",
      description: "Unique visitors over time, with 24h / 7d / 30d toggle.",
      iconName: "eye",
      defaultSize: 6,
      tint: "mint",
      component: VisitorsWidget
    });
    api.dashboard.widgets.register({
      id: "pagebuilder.analytics.top-pages",
      name: "Top pages",
      description: "Most-viewed URLs over the last 7 days.",
      iconName: "star",
      defaultSize: 4,
      tint: "lilac",
      component: TopPagesWidget
    });
  }
};
var editor_default = mod;
export {
  editor_default as default
};
