(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // examples/plugins/showcase/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    default: () => server_default
  });
  var STATUS_TAG = "<!-- plugin:acme.showcase -->";
  var mod = {
    install(api) {
      api.plugin.log("Showcase plugin installed");
    },
    activate(api) {
      api.plugin.log("Showcase plugin activated");
      const events = api.cms.storage.collection("events");
      api.cms.routes.get("/status", "plugins.read", async () => {
        const { records } = await events.list();
        const byEvent = {};
        for (const record of records) {
          const name = String(record.data.name || "unknown");
          byEvent[name] = (byEvent[name] || 0) + 1;
        }
        return {
          ok: true,
          plugin: api.plugin.id,
          total: records.length,
          byEvent
        };
      });
      api.cms.routes.post("/clear", "plugins.configure", async () => {
        const { records } = await events.list();
        await Promise.all(records.map((r) => events.delete(r.id)));
        return { ok: true, deleted: records.length };
      });
      api.cms.routes.public.post("/ingest", async (ctx) => {
        const body = ctx.body ?? {};
        const eventName = typeof body.eventName === "string" ? body.eventName : "";
        if (!eventName) {
          return { __response: true, status: 400, headers: {}, body: '{"error":"missing eventName"}' };
        }
        const prefix = api.cms.settings.get("eventLabelPrefix") ?? "";
        const storeOutbound = api.cms.settings.get("storeOutboundClicks") ?? true;
        if (eventName === "link-click" && !storeOutbound)
          return { ok: true, skipped: true };
        const payload = body.payload && typeof body.payload === "object" && !Array.isArray(body.payload) ? body.payload : {};
        try {
          await events.create({
            name: prefix ? `${prefix}:${eventName}` : eventName,
            page: typeof body.pagePath === "string" ? body.pagePath : "",
            visitor: typeof body.visitorId === "string" ? body.visitorId : "",
            session: typeof body.sessionId === "string" ? body.sessionId : "",
            payload: JSON.stringify(payload),
            "received-at": new Date().toISOString()
          });
          return { ok: true };
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          api.plugin.log("storage failed", message);
          return { __response: true, status: 500, headers: {}, body: '{"error":"storage failed"}' };
        }
      });
      api.cms.hooks.filter("publish.html", (html) => {
        if (typeof html !== "string")
          return html;
        return html.replace("</body>", `${STATUS_TAG}
</body>`);
      });
    },
    deactivate(api) {
      api.plugin.log("Showcase plugin deactivated");
    },
    async uninstall(api) {
      const events = api.cms.storage.collection("events");
      const { records } = await events.list();
      await Promise.all(records.map((r) => events.delete(r.id)));
      api.plugin.log(`Showcase plugin removed ${records.length} events`);
    }
  };
  var server_default = mod;

  // examples/plugins/showcase/server/__sandbox-facade-1779996242096.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
