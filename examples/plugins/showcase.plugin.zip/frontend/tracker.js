// examples/plugins/showcase/frontend/tracker.ts
var PLUGIN_ID = "acme.showcase";
var ROUTE_BASE = `/admin/api/cms/plugins/${PLUGIN_ID}/runtime`;
(function init() {
  function rid() {
    return (Math.random().toString(36).slice(2) + Date.now().toString(36)).slice(0, 16);
  }
  function persistentId(storage, key) {
    try {
      const existing = storage.getItem(key);
      if (existing)
        return existing;
      const fresh = rid();
      storage.setItem(key, fresh);
      return fresh;
    } catch {
      return rid();
    }
  }
  const visitorId = persistentId(localStorage, "__acme_showcase_v");
  const sessionId = persistentId(sessionStorage, "__acme_showcase_s");
  function send(eventName, payload) {
    bumpCounter(eventName);
    fetch(`${ROUTE_BASE}/ingest`, {
      method: "POST",
      credentials: "omit",
      headers: { "Content-Type": "application/json" },
      keepalive: true,
      body: JSON.stringify({
        eventName,
        payload,
        visitorId,
        sessionId,
        pagePath: location.pathname,
        referrer: document.referrer || null
      })
    }).catch(() => {});
  }
  const counts = new Map;
  function bumpCounter(eventName) {
    const next = (counts.get(eventName) || 0) + 1;
    counts.set(eventName, next);
    document.querySelectorAll(`[data-pb-counter="${CSS.escape(eventName)}"] [data-pb-counter-value]`).forEach((el) => {
      el.textContent = String(next);
    });
  }
  function firePageView() {
    send("page-view", { path: location.pathname, title: document.title });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", firePageView, { once: true });
  } else {
    firePageView();
  }
  document.addEventListener("click", (e) => {
    const target = e.target;
    const anchor = target?.closest?.("a[href]");
    if (!anchor)
      return;
    send("link-click", {
      href: anchor.getAttribute("href") ?? "",
      text: (anchor.textContent ?? "").trim().slice(0, 80)
    });
  }, { capture: true });
  const seen = {};
  window.addEventListener("scroll", () => {
    const pct = Math.round((window.scrollY + window.innerHeight) / document.documentElement.scrollHeight * 100);
    for (const t of [25, 50, 75, 100]) {
      if (pct >= t && !seen[t]) {
        seen[t] = true;
        send("scroll-depth", { depth: t });
      }
    }
  }, { passive: true });
})();
