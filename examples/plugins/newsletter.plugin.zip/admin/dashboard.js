// examples/plugins/newsletter/admin/dashboard.tsx
import { useState as useState6 } from "react";
import { Heading as Heading6, Stack as Stack6, Tab, TabList, TabPanel, Tabs, Text as Text6 } from "@pagebuilder/host-ui";
import { definePluginAdminApp } from "@pagebuilder/plugin-sdk";

// examples/plugins/newsletter/admin/sections/Stats.tsx
import { useCallback, useEffect, useState } from "react";
import { Alert, Card, Heading, Stack, Text } from "@pagebuilder/host-ui";
import { usePluginRoutes } from "@pagebuilder/host-hooks";
import { jsxDEV } from "react/jsx-dev-runtime";
function StatRow({ label, value }) {
  return /* @__PURE__ */ jsxDEV(Stack, {
    direction: "row",
    gap: 8,
    children: [
      /* @__PURE__ */ jsxDEV(Text, {
        variant: "muted",
        style: { minWidth: 140 },
        children: label
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV(Text, {
        children: /* @__PURE__ */ jsxDEV("strong", {
          children: value
        }, undefined, false, undefined, this)
      }, undefined, false, undefined, this)
    ]
  }, undefined, true, undefined, this);
}
function Stats() {
  const routes = usePluginRoutes();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await routes.fetch("stats");
      setData(await res.json());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load stats");
    } finally {
      setLoading(false);
    }
  }, [routes]);
  useEffect(() => {
    refresh();
  }, [refresh]);
  if (loading)
    return /* @__PURE__ */ jsxDEV(Text, {
      variant: "muted",
      children: "Loading stats…"
    }, undefined, false, undefined, this);
  if (error)
    return /* @__PURE__ */ jsxDEV(Alert, {
      tone: "danger",
      title: "Error",
      children: error
    }, undefined, false, undefined, this);
  if (!data)
    return null;
  const openRate = data.deliveries.total > 0 ? Math.round(data.deliveries.opened / data.deliveries.total * 100) : 0;
  const clickRate = data.deliveries.total > 0 ? Math.round(data.deliveries.clicked / data.deliveries.total * 100) : 0;
  return /* @__PURE__ */ jsxDEV(Stack, {
    gap: 16,
    children: [
      /* @__PURE__ */ jsxDEV(Heading, {
        level: 3,
        children: "Overview"
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV(Stack, {
        direction: "row",
        gap: 16,
        wrap: true,
        children: [
          /* @__PURE__ */ jsxDEV(Card, {
            padding: 16,
            style: { flex: "1 1 200px" },
            children: /* @__PURE__ */ jsxDEV(Stack, {
              gap: 8,
              children: [
                /* @__PURE__ */ jsxDEV(Heading, {
                  level: 4,
                  children: "Subscribers"
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Total",
                  value: data.subscribers.total
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Confirmed",
                  value: data.subscribers.confirmed
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Pending",
                  value: data.subscribers.pending
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Unsubscribed",
                  value: data.subscribers.unsubscribed
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Bounced",
                  value: data.subscribers.bounced
                }, undefined, false, undefined, this)
              ]
            }, undefined, true, undefined, this)
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV(Card, {
            padding: 16,
            style: { flex: "1 1 200px" },
            children: /* @__PURE__ */ jsxDEV(Stack, {
              gap: 8,
              children: [
                /* @__PURE__ */ jsxDEV(Heading, {
                  level: 4,
                  children: "Broadcasts"
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Sent",
                  value: data.broadcasts.sent
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Scheduled",
                  value: data.broadcasts.scheduled
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Draft",
                  value: data.broadcasts.draft
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Failed",
                  value: data.broadcasts.failed
                }, undefined, false, undefined, this)
              ]
            }, undefined, true, undefined, this)
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV(Card, {
            padding: 16,
            style: { flex: "1 1 200px" },
            children: /* @__PURE__ */ jsxDEV(Stack, {
              gap: 8,
              children: [
                /* @__PURE__ */ jsxDEV(Heading, {
                  level: 4,
                  children: "Engagement"
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Total sent",
                  value: data.deliveries.total
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Opens",
                  value: `${data.deliveries.opened} (${openRate}%)`
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatRow, {
                  label: "Clicks",
                  value: `${data.deliveries.clicked} (${clickRate}%)`
                }, undefined, false, undefined, this)
              ]
            }, undefined, true, undefined, this)
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this)
    ]
  }, undefined, true, undefined, this);
}

// examples/plugins/newsletter/admin/sections/Subscribers.tsx
import { useCallback as useCallback2, useEffect as useEffect2, useState as useState2 } from "react";
import {
  Alert as Alert2,
  Button,
  Card as Card2,
  Heading as Heading2,
  Input,
  SearchBar,
  Select,
  Stack as Stack2,
  Text as Text2
} from "@pagebuilder/host-ui";
import { usePluginRoutes as usePluginRoutes2 } from "@pagebuilder/host-hooks";
import { jsxDEV as jsxDEV2, Fragment } from "react/jsx-dev-runtime";
var PAGE_SIZE = 20;
var STATUS_OPTIONS = [
  { value: "", label: "All statuses" },
  { value: "confirmed", label: "Confirmed" },
  { value: "pending", label: "Pending" },
  { value: "unsubscribed", label: "Unsubscribed" },
  { value: "bounced", label: "Bounced" }
];
function statusStyle(status) {
  const map = {
    confirmed: { background: "var(--editor-success-bg)", color: "var(--editor-success-green)" },
    pending: { background: "var(--panel-border)", color: "var(--editor-text-muted)" },
    unsubscribed: { background: "var(--panel-border)", color: "var(--editor-text-muted)" },
    bounced: { background: "var(--editor-danger-bg)", color: "var(--editor-danger)" }
  };
  const s = map[status] ?? map.pending;
  return {
    display: "inline-block",
    padding: "1px 7px",
    fontSize: 11,
    fontWeight: 600,
    borderRadius: 4,
    textTransform: "uppercase",
    letterSpacing: "0.04em",
    ...s
  };
}
function Subscribers() {
  const routes = usePluginRoutes2();
  const [subscribers, setSubscribers] = useState2([]);
  const [totalCount, setTotalCount] = useState2(0);
  const [lists, setLists] = useState2([]);
  const [error, setError] = useState2(null);
  const [loading, setLoading] = useState2(true);
  const [search, setSearch] = useState2("");
  const [statusFilter, setStatusFilter] = useState2("");
  const [listFilter, setListFilter] = useState2("");
  const [page, setPage] = useState2(0);
  const [modalOpen, setModalOpen] = useState2(false);
  const [addEmail, setAddEmail] = useState2("");
  const [addName, setAddName] = useState2("");
  const [addListId, setAddListId] = useState2("");
  const [addError, setAddError] = useState2(null);
  const [adding, setAdding] = useState2(false);
  const refresh = useCallback2(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams;
      if (statusFilter)
        params.set("status", statusFilter);
      if (listFilter)
        params.set("listId", listFilter);
      if (search)
        params.set("search", search);
      params.set("limit", String(PAGE_SIZE));
      params.set("offset", String(page * PAGE_SIZE));
      const [subRes, listRes] = await Promise.all([
        routes.fetch(`subscribers?${params}`),
        routes.fetch("lists")
      ]);
      const subBody = await subRes.json();
      const listBody = await listRes.json();
      if (subBody.error)
        throw new Error(subBody.error);
      setSubscribers(subBody.subscribers ?? []);
      setTotalCount(subBody.totalCount ?? 0);
      setLists(listBody.lists ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load subscribers");
    } finally {
      setLoading(false);
    }
  }, [routes, statusFilter, listFilter, search, page]);
  useEffect2(() => {
    refresh();
  }, [refresh]);
  const totalPages = Math.ceil(totalCount / PAGE_SIZE);
  async function handleDelete(id) {
    try {
      await routes.fetch(`subscribers/${id}`, { method: "DELETE" });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Delete failed");
    }
  }
  async function handleAdd() {
    if (!addEmail.trim()) {
      setAddError("Email is required");
      return;
    }
    setAdding(true);
    setAddError(null);
    try {
      const res = await routes.fetch("subscribers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: addEmail.trim(),
          name: addName.trim(),
          listIds: addListId ? [addListId] : []
        })
      });
      const body = await res.json();
      if (body.error)
        throw new Error(body.error);
      setModalOpen(false);
      setAddEmail("");
      setAddName("");
      setAddListId("");
      await refresh();
    } catch (err) {
      setAddError(err instanceof Error ? err.message : "Failed to add subscriber");
    } finally {
      setAdding(false);
    }
  }
  async function handleExportCsv() {
    try {
      const res = await routes.fetch("subscribers.csv");
      const csv = await res.text();
      const blob = new Blob([csv], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "subscribers.csv";
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export failed");
    }
  }
  const listOptions = [
    { value: "", label: "All lists" },
    ...lists.map((l) => ({ value: l.id, label: l.name }))
  ];
  return /* @__PURE__ */ jsxDEV2(Stack2, {
    gap: 16,
    children: [
      /* @__PURE__ */ jsxDEV2(Stack2, {
        direction: "row",
        gap: 8,
        children: [
          /* @__PURE__ */ jsxDEV2(Heading2, {
            level: 3,
            style: { flex: 1 },
            children: "Subscribers"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV2(Button, {
            variant: "secondary",
            size: "sm",
            onClick: () => void handleExportCsv(),
            children: "Export CSV"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV2(Button, {
            variant: "primary",
            size: "sm",
            onClick: () => setModalOpen(true),
            children: "Add subscriber"
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this),
      error && /* @__PURE__ */ jsxDEV2(Alert2, {
        tone: "danger",
        title: "Error",
        role: "alert",
        children: error
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV2(Stack2, {
        direction: "row",
        gap: 8,
        wrap: true,
        children: [
          /* @__PURE__ */ jsxDEV2(SearchBar, {
            placeholder: "Search by email…",
            value: search,
            onChange: (e) => {
              setSearch(e.target.value);
              setPage(0);
            },
            style: { flex: "1 1 200px" }
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV2(Select, {
            value: statusFilter,
            options: STATUS_OPTIONS,
            onChange: (e) => {
              setStatusFilter(e.target.value);
              setPage(0);
            },
            style: { flex: "0 0 160px" }
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV2(Select, {
            value: listFilter,
            options: listOptions,
            onChange: (e) => {
              setListFilter(e.target.value);
              setPage(0);
            },
            style: { flex: "0 0 160px" }
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this),
      loading ? /* @__PURE__ */ jsxDEV2(Text2, {
        variant: "muted",
        children: "Loading…"
      }, undefined, false, undefined, this) : subscribers.length === 0 ? /* @__PURE__ */ jsxDEV2(Alert2, {
        tone: "info",
        title: "No subscribers found",
        children: search || statusFilter || listFilter ? "Try adjusting your filters." : "No subscribers yet."
      }, undefined, false, undefined, this) : /* @__PURE__ */ jsxDEV2(Fragment, {
        children: [
          /* @__PURE__ */ jsxDEV2("table", {
            style: { width: "100%", borderCollapse: "collapse", fontSize: 13 },
            children: [
              /* @__PURE__ */ jsxDEV2("thead", {
                children: /* @__PURE__ */ jsxDEV2("tr", {
                  style: { borderBottom: "1px solid var(--panel-border)" },
                  children: ["Email", "Name", "Status", "Lists", "Subscribed", ""].map((h) => /* @__PURE__ */ jsxDEV2("th", {
                    style: {
                      textAlign: "left",
                      padding: "6px 8px",
                      color: "var(--editor-text-muted)",
                      fontWeight: 500
                    },
                    children: h
                  }, h, false, undefined, this))
                }, undefined, false, undefined, this)
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV2("tbody", {
                children: subscribers.map((sub) => /* @__PURE__ */ jsxDEV2("tr", {
                  style: { borderBottom: "1px solid var(--panel-border)" },
                  children: [
                    /* @__PURE__ */ jsxDEV2("td", {
                      style: { padding: "8px 8px" },
                      children: sub.email
                    }, undefined, false, undefined, this),
                    /* @__PURE__ */ jsxDEV2("td", {
                      style: { padding: "8px 8px", color: "var(--editor-text-muted)" },
                      children: sub.name || "—"
                    }, undefined, false, undefined, this),
                    /* @__PURE__ */ jsxDEV2("td", {
                      style: { padding: "8px 8px" },
                      children: /* @__PURE__ */ jsxDEV2("span", {
                        style: statusStyle(sub.status),
                        children: sub.status
                      }, undefined, false, undefined, this)
                    }, undefined, false, undefined, this),
                    /* @__PURE__ */ jsxDEV2("td", {
                      style: { padding: "8px 8px", color: "var(--editor-text-muted)" },
                      children: sub.listIds.length === 0 ? "—" : sub.listIds.map((id) => lists.find((l) => l.id === id)?.name ?? id).join(", ")
                    }, undefined, false, undefined, this),
                    /* @__PURE__ */ jsxDEV2("td", {
                      style: { padding: "8px 8px", color: "var(--editor-text-muted)" },
                      children: sub.subscribedAt ? new Date(sub.subscribedAt).toLocaleDateString() : "—"
                    }, undefined, false, undefined, this),
                    /* @__PURE__ */ jsxDEV2("td", {
                      style: { padding: "8px 8px" },
                      children: /* @__PURE__ */ jsxDEV2(Button, {
                        variant: "destructive",
                        size: "sm",
                        onClick: () => void handleDelete(sub.id),
                        children: "Remove"
                      }, undefined, false, undefined, this)
                    }, undefined, false, undefined, this)
                  ]
                }, sub.id, true, undefined, this))
              }, undefined, false, undefined, this)
            ]
          }, undefined, true, undefined, this),
          totalPages > 1 && /* @__PURE__ */ jsxDEV2(Stack2, {
            direction: "row",
            gap: 8,
            children: [
              /* @__PURE__ */ jsxDEV2(Button, {
                variant: "secondary",
                size: "sm",
                onClick: () => setPage((p) => Math.max(0, p - 1)),
                disabled: page === 0,
                children: "← Prev"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV2(Text2, {
                variant: "muted",
                children: [
                  "Page ",
                  page + 1,
                  " of ",
                  totalPages,
                  " (",
                  totalCount,
                  " total)"
                ]
              }, undefined, true, undefined, this),
              /* @__PURE__ */ jsxDEV2(Button, {
                variant: "secondary",
                size: "sm",
                onClick: () => setPage((p) => Math.min(totalPages - 1, p + 1)),
                disabled: page >= totalPages - 1,
                children: "Next →"
              }, undefined, false, undefined, this)
            ]
          }, undefined, true, undefined, this)
        ]
      }, undefined, true, undefined, this),
      modalOpen && /* @__PURE__ */ jsxDEV2("div", {
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "Add subscriber",
        children: /* @__PURE__ */ jsxDEV2(Card2, {
          padding: 24,
          children: /* @__PURE__ */ jsxDEV2(Stack2, {
            gap: 16,
            children: [
              /* @__PURE__ */ jsxDEV2(Heading2, {
                level: 4,
                children: "Add subscriber"
              }, undefined, false, undefined, this),
              addError && /* @__PURE__ */ jsxDEV2(Alert2, {
                tone: "danger",
                title: "Error",
                role: "alert",
                children: addError
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV2(Input, {
                label: "Email",
                type: "email",
                value: addEmail,
                onChange: (e) => setAddEmail(e.target.value),
                placeholder: "subscriber@example.com"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV2(Input, {
                label: "Name (optional)",
                value: addName,
                onChange: (e) => setAddName(e.target.value),
                placeholder: "Jane Smith"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV2(Select, {
                label: "List",
                value: addListId,
                options: [{ value: "", label: "Default list" }, ...lists.map((l) => ({ value: l.id, label: l.name }))],
                onChange: (e) => setAddListId(e.target.value)
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV2(Stack2, {
                direction: "row",
                gap: 8,
                children: [
                  /* @__PURE__ */ jsxDEV2(Button, {
                    variant: "primary",
                    size: "sm",
                    onClick: () => void handleAdd(),
                    disabled: adding,
                    children: adding ? "Adding…" : "Add"
                  }, undefined, false, undefined, this),
                  /* @__PURE__ */ jsxDEV2(Button, {
                    variant: "secondary",
                    size: "sm",
                    onClick: () => setModalOpen(false),
                    children: "Cancel"
                  }, undefined, false, undefined, this)
                ]
              }, undefined, true, undefined, this)
            ]
          }, undefined, true, undefined, this)
        }, undefined, false, undefined, this)
      }, undefined, false, undefined, this)
    ]
  }, undefined, true, undefined, this);
}

// examples/plugins/newsletter/admin/sections/Lists.tsx
import { useCallback as useCallback3, useEffect as useEffect3, useState as useState3 } from "react";
import { Alert as Alert3, Button as Button2, Card as Card3, Heading as Heading3, Input as Input2, Stack as Stack3, Text as Text3, Switch } from "@pagebuilder/host-ui";
import { usePluginRoutes as usePluginRoutes3 } from "@pagebuilder/host-hooks";
import { jsxDEV as jsxDEV3 } from "react/jsx-dev-runtime";
var emptyForm = { name: "", description: "", isDefault: false };
function Lists() {
  const routes = usePluginRoutes3();
  const [lists, setLists] = useState3([]);
  const [error, setError] = useState3(null);
  const [loading, setLoading] = useState3(true);
  const [modalOpen, setModalOpen] = useState3(false);
  const [editId, setEditId] = useState3(null);
  const [form, setForm] = useState3(emptyForm);
  const [saving, setSaving] = useState3(false);
  const [formError, setFormError] = useState3(null);
  const refresh = useCallback3(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await routes.fetch("lists");
      const body = await res.json();
      if (body.error)
        throw new Error(body.error);
      setLists(body.lists ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load lists");
    } finally {
      setLoading(false);
    }
  }, [routes]);
  useEffect3(() => {
    refresh();
  }, [refresh]);
  function openCreate() {
    setEditId(null);
    setForm(emptyForm);
    setFormError(null);
    setModalOpen(true);
  }
  function openEdit(list) {
    setEditId(list.id);
    setForm({ name: list.name, description: list.description, isDefault: list.isDefault });
    setFormError(null);
    setModalOpen(true);
  }
  async function handleSave() {
    if (!form.name.trim()) {
      setFormError("Name is required");
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const res = editId ? await routes.fetch(`lists/${editId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }) : await routes.fetch("lists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const body = await res.json();
      if (body.error)
        throw new Error(body.error);
      setModalOpen(false);
      await refresh();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }
  async function handleDelete(id) {
    try {
      await routes.fetch(`lists/${id}`, { method: "DELETE" });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Delete failed");
    }
  }
  if (loading)
    return /* @__PURE__ */ jsxDEV3(Text3, {
      variant: "muted",
      children: "Loading lists…"
    }, undefined, false, undefined, this);
  return /* @__PURE__ */ jsxDEV3(Stack3, {
    gap: 16,
    children: [
      /* @__PURE__ */ jsxDEV3(Stack3, {
        direction: "row",
        gap: 8,
        children: [
          /* @__PURE__ */ jsxDEV3(Heading3, {
            level: 3,
            style: { flex: 1 },
            children: "Lists"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV3(Button2, {
            variant: "primary",
            size: "sm",
            onClick: openCreate,
            children: "New list"
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this),
      error && /* @__PURE__ */ jsxDEV3(Alert3, {
        tone: "danger",
        title: "Error",
        role: "alert",
        children: error
      }, undefined, false, undefined, this),
      lists.length === 0 && !loading && /* @__PURE__ */ jsxDEV3(Alert3, {
        tone: "info",
        title: "No lists yet",
        children: "Create a list to start segmenting your subscribers."
      }, undefined, false, undefined, this),
      lists.map((list) => /* @__PURE__ */ jsxDEV3(Card3, {
        padding: 12,
        children: /* @__PURE__ */ jsxDEV3(Stack3, {
          direction: "row",
          gap: 8,
          children: [
            /* @__PURE__ */ jsxDEV3(Stack3, {
              gap: 4,
              style: { flex: 1 },
              children: [
                /* @__PURE__ */ jsxDEV3(Text3, {
                  children: [
                    /* @__PURE__ */ jsxDEV3("strong", {
                      children: list.name
                    }, undefined, false, undefined, this),
                    list.isDefault && /* @__PURE__ */ jsxDEV3("span", {
                      style: {
                        marginLeft: 8,
                        fontSize: 11,
                        padding: "2px 6px",
                        background: "var(--editor-success-bg)",
                        color: "var(--editor-success-green)",
                        borderRadius: 4
                      },
                      children: "default"
                    }, undefined, false, undefined, this)
                  ]
                }, undefined, true, undefined, this),
                list.description && /* @__PURE__ */ jsxDEV3(Text3, {
                  variant: "muted",
                  children: list.description
                }, undefined, false, undefined, this)
              ]
            }, undefined, true, undefined, this),
            /* @__PURE__ */ jsxDEV3(Button2, {
              variant: "secondary",
              size: "sm",
              onClick: () => openEdit(list),
              children: "Edit"
            }, undefined, false, undefined, this),
            /* @__PURE__ */ jsxDEV3(Button2, {
              variant: "destructive",
              size: "sm",
              onClick: () => void handleDelete(list.id),
              disabled: list.isDefault,
              children: "Delete"
            }, undefined, false, undefined, this)
          ]
        }, undefined, true, undefined, this)
      }, list.id, false, undefined, this)),
      modalOpen && /* @__PURE__ */ jsxDEV3("div", {
        role: "dialog",
        "aria-modal": "true",
        "aria-label": editId ? "Edit list" : "Create list",
        children: /* @__PURE__ */ jsxDEV3(Card3, {
          padding: 24,
          children: /* @__PURE__ */ jsxDEV3(Stack3, {
            gap: 16,
            children: [
              /* @__PURE__ */ jsxDEV3(Heading3, {
                level: 4,
                children: editId ? "Edit list" : "Create list"
              }, undefined, false, undefined, this),
              formError && /* @__PURE__ */ jsxDEV3(Alert3, {
                tone: "danger",
                title: "Error",
                role: "alert",
                children: formError
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV3(Input2, {
                label: "Name",
                value: form.name,
                onChange: (e) => setForm((f) => ({ ...f, name: e.target.value })),
                placeholder: "General"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV3(Input2, {
                label: "Description",
                value: form.description,
                onChange: (e) => setForm((f) => ({ ...f, description: e.target.value })),
                placeholder: "Main newsletter list"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV3(Switch, {
                label: "Default list",
                checked: form.isDefault,
                onChange: (checked) => setForm((f) => ({ ...f, isDefault: checked }))
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV3(Stack3, {
                direction: "row",
                gap: 8,
                children: [
                  /* @__PURE__ */ jsxDEV3(Button2, {
                    variant: "primary",
                    size: "sm",
                    onClick: () => void handleSave(),
                    disabled: saving,
                    children: saving ? "Saving…" : "Save"
                  }, undefined, false, undefined, this),
                  /* @__PURE__ */ jsxDEV3(Button2, {
                    variant: "secondary",
                    size: "sm",
                    onClick: () => setModalOpen(false),
                    children: "Cancel"
                  }, undefined, false, undefined, this)
                ]
              }, undefined, true, undefined, this)
            ]
          }, undefined, true, undefined, this)
        }, undefined, false, undefined, this)
      }, undefined, false, undefined, this)
    ]
  }, undefined, true, undefined, this);
}

// examples/plugins/newsletter/admin/sections/Broadcasts.tsx
import { useCallback as useCallback4, useEffect as useEffect4, useState as useState5 } from "react";
import { Alert as Alert5, Button as Button4, Card as Card4, Heading as Heading5, Stack as Stack5, Text as Text5 } from "@pagebuilder/host-ui";
import { usePluginRoutes as usePluginRoutes5 } from "@pagebuilder/host-hooks";

// examples/plugins/newsletter/admin/sections/BroadcastComposer.tsx
import { useState as useState4 } from "react";
import { Alert as Alert4, Button as Button3, Heading as Heading4, Input as Input3, Stack as Stack4, Text as Text4, Textarea } from "@pagebuilder/host-ui";
import { usePluginRoutes as usePluginRoutes4 } from "@pagebuilder/host-hooks";
import { jsxDEV as jsxDEV4, Fragment as Fragment2 } from "react/jsx-dev-runtime";
function BroadcastComposer({ lists, broadcast, onClose, onSaved }) {
  const routes = usePluginRoutes4();
  const [subject, setSubject] = useState4(broadcast?.subject ?? "");
  const [htmlBody, setHtmlBody] = useState4(broadcast?.htmlBody ?? "");
  const [plainBody, setPlainBody] = useState4(broadcast?.plainBody ?? "");
  const [selectedListIds, setSelectedListIds] = useState4(broadcast?.listIds ?? []);
  const [scheduledAt, setScheduledAt] = useState4("");
  const [previewEmail, setPreviewEmail] = useState4("");
  const [showPreviewInput, setShowPreviewInput] = useState4(false);
  const [error, setError] = useState4(null);
  const [status, setStatus] = useState4(null);
  const [saving, setSaving] = useState4(false);
  const [sending, setSending] = useState4(false);
  const [currentId, setCurrentId] = useState4(broadcast?.id ?? null);
  function toggleList(id) {
    setSelectedListIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  }
  async function handleSaveDraft() {
    if (!subject.trim()) {
      setError("Subject is required");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const payload = { subject, htmlBody, plainBody, listIds: selectedListIds };
      const res = currentId ? await routes.fetch(`broadcasts/${currentId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      }) : await routes.fetch("broadcasts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const body = await res.json();
      if (body.error)
        throw new Error(body.error);
      if (body.broadcast) {
        setCurrentId(body.broadcast.id);
        onSaved(body.broadcast);
      }
      setStatus("Draft saved.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }
  async function handleSchedule() {
    if (!scheduledAt) {
      setError("Please enter a scheduled date/time");
      return;
    }
    if (!currentId) {
      setError("Save as draft first");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const res = await routes.fetch(`broadcasts/${currentId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scheduledAt: new Date(scheduledAt).toISOString() })
      });
      const body = await res.json();
      if (body.error)
        throw new Error(body.error);
      setStatus("Broadcast scheduled.");
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Schedule failed");
    } finally {
      setSaving(false);
    }
  }
  async function handleSendNow() {
    if (!currentId) {
      setError("Save as draft first");
      return;
    }
    setSending(true);
    setError(null);
    try {
      const res = await routes.fetch(`broadcasts/${currentId}/send`, { method: "POST" });
      const body = await res.json();
      if (body.error)
        throw new Error(body.error);
      setStatus(`Sent to ${body.recipientCount ?? 0} recipient(s).`);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Send failed");
    } finally {
      setSending(false);
    }
  }
  async function handleSendPreview() {
    if (!currentId) {
      setError("Save as draft first");
      return;
    }
    if (!previewEmail.trim()) {
      setError("Enter a preview email address");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const res = await routes.fetch(`broadcasts/${currentId}/preview`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: previewEmail.trim() })
      });
      const body = await res.json();
      if (body.error)
        throw new Error(body.error);
      setStatus(`Preview sent to ${previewEmail}.`);
      setShowPreviewInput(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Preview send failed");
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxDEV4(Stack4, {
    gap: 16,
    children: [
      /* @__PURE__ */ jsxDEV4(Stack4, {
        direction: "row",
        gap: 8,
        children: [
          /* @__PURE__ */ jsxDEV4(Heading4, {
            level: 3,
            style: { flex: 1 },
            children: currentId ? "Edit broadcast" : "New broadcast"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV4(Button3, {
            variant: "secondary",
            size: "sm",
            onClick: onClose,
            children: "← Back"
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this),
      error && /* @__PURE__ */ jsxDEV4(Alert4, {
        tone: "danger",
        title: "Error",
        role: "alert",
        children: error
      }, undefined, false, undefined, this),
      status && /* @__PURE__ */ jsxDEV4(Alert4, {
        tone: "success",
        title: "Done",
        role: "status",
        children: status
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV4(Input3, {
        label: "Subject",
        value: subject,
        onChange: (e) => setSubject(e.target.value),
        placeholder: "Your newsletter subject"
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV4(Stack4, {
        gap: 4,
        children: [
          /* @__PURE__ */ jsxDEV4(Text4, {
            children: "Lists"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV4(Stack4, {
            direction: "row",
            gap: 8,
            wrap: true,
            children: [
              lists.length === 0 && /* @__PURE__ */ jsxDEV4(Text4, {
                variant: "muted",
                children: "No lists yet — create one in the Lists tab."
              }, undefined, false, undefined, this),
              lists.map((list) => /* @__PURE__ */ jsxDEV4("label", {
                style: {
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  cursor: "pointer",
                  fontSize: 13,
                  padding: "4px 10px",
                  borderRadius: 4,
                  border: "1px solid var(--panel-border)",
                  background: selectedListIds.includes(list.id) ? "var(--editor-success-bg)" : "transparent"
                },
                children: [
                  /* @__PURE__ */ jsxDEV4("input", {
                    type: "checkbox",
                    checked: selectedListIds.includes(list.id),
                    onChange: () => toggleList(list.id)
                  }, undefined, false, undefined, this),
                  list.name
                ]
              }, list.id, true, undefined, this))
            ]
          }, undefined, true, undefined, this),
          selectedListIds.length === 0 && /* @__PURE__ */ jsxDEV4(Text4, {
            variant: "muted",
            style: { fontSize: 12 },
            children: "No lists selected — broadcast will send to all confirmed subscribers."
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this),
      /* @__PURE__ */ jsxDEV4(Stack4, {
        direction: "row",
        gap: 16,
        children: [
          /* @__PURE__ */ jsxDEV4(Stack4, {
            gap: 4,
            style: { flex: 1 },
            children: [
              /* @__PURE__ */ jsxDEV4(Text4, {
                children: "HTML body"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV4(Textarea, {
                value: htmlBody,
                onChange: (e) => setHtmlBody(e.target.value),
                placeholder: "<p>Hello {{name}},</p>...",
                rows: 16,
                style: { fontFamily: "monospace", fontSize: 12 }
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV4(Text4, {
                variant: "muted",
                style: { fontSize: 12 },
                children: [
                  "Available placeholders: ",
                  "{{preferences_url}}",
                  ", ",
                  "{{unsubscribe_url}}"
                ]
              }, undefined, true, undefined, this)
            ]
          }, undefined, true, undefined, this),
          /* @__PURE__ */ jsxDEV4(Stack4, {
            gap: 4,
            style: { flex: 1 },
            children: [
              /* @__PURE__ */ jsxDEV4(Text4, {
                children: "Preview"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV4("iframe", {
                srcDoc: htmlBody || '<p style="color:#aaa;font-family:sans-serif;padding:16px">HTML preview will appear here.</p>',
                style: {
                  border: "1px solid var(--panel-border)",
                  borderRadius: 4,
                  width: "100%",
                  height: 340,
                  background: "#fff"
                },
                title: "Email preview",
                sandbox: "allow-same-origin"
              }, undefined, false, undefined, this)
            ]
          }, undefined, true, undefined, this)
        ]
      }, undefined, true, undefined, this),
      /* @__PURE__ */ jsxDEV4(Textarea, {
        label: "Plain-text body (optional)",
        value: plainBody,
        onChange: (e) => setPlainBody(e.target.value),
        placeholder: "Plain text version for email clients that don't render HTML.",
        rows: 4
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV4(Stack4, {
        gap: 8,
        children: [
          /* @__PURE__ */ jsxDEV4(Text4, {
            children: "Schedule"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV4(Stack4, {
            direction: "row",
            gap: 8,
            children: [
              /* @__PURE__ */ jsxDEV4("input", {
                type: "datetime-local",
                value: scheduledAt,
                onChange: (e) => setScheduledAt(e.target.value),
                style: {
                  padding: "8px 12px",
                  border: "1px solid var(--panel-border)",
                  borderRadius: 6,
                  fontSize: 13,
                  color: "inherit",
                  background: "var(--input-bg)"
                }
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV4(Button3, {
                variant: "secondary",
                size: "sm",
                onClick: () => void handleSchedule(),
                disabled: saving || !scheduledAt || !currentId,
                children: "Schedule"
              }, undefined, false, undefined, this)
            ]
          }, undefined, true, undefined, this)
        ]
      }, undefined, true, undefined, this),
      /* @__PURE__ */ jsxDEV4(Stack4, {
        direction: "row",
        gap: 8,
        wrap: true,
        children: [
          /* @__PURE__ */ jsxDEV4(Button3, {
            variant: "secondary",
            size: "sm",
            onClick: () => void handleSaveDraft(),
            disabled: saving,
            children: saving ? "Saving…" : "Save draft"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV4(Button3, {
            variant: "primary",
            size: "sm",
            onClick: () => void handleSendNow(),
            disabled: sending || !currentId,
            children: sending ? "Sending…" : "Send now"
          }, undefined, false, undefined, this),
          showPreviewInput ? /* @__PURE__ */ jsxDEV4(Fragment2, {
            children: [
              /* @__PURE__ */ jsxDEV4(Input3, {
                value: previewEmail,
                onChange: (e) => setPreviewEmail(e.target.value),
                placeholder: "preview@example.com",
                type: "email",
                style: { flex: "1 1 200px" }
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV4(Button3, {
                variant: "secondary",
                size: "sm",
                onClick: () => void handleSendPreview(),
                disabled: saving || !currentId,
                children: "Send preview"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV4(Button3, {
                variant: "ghost",
                size: "sm",
                onClick: () => setShowPreviewInput(false),
                children: "Cancel"
              }, undefined, false, undefined, this)
            ]
          }, undefined, true, undefined, this) : /* @__PURE__ */ jsxDEV4(Button3, {
            variant: "ghost",
            size: "sm",
            onClick: () => setShowPreviewInput(true),
            disabled: !currentId,
            children: "Send preview…"
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this)
    ]
  }, undefined, true, undefined, this);
}

// examples/plugins/newsletter/admin/sections/Broadcasts.tsx
import { jsxDEV as jsxDEV5, Fragment as Fragment3 } from "react/jsx-dev-runtime";
function statusStyle2(status) {
  const map = {
    draft: { background: "var(--panel-border)", color: "var(--editor-text-muted)" },
    scheduled: { background: "var(--editor-warning-bg, #fef9c3)", color: "#854d0e" },
    sending: { background: "var(--editor-warning-bg, #fef9c3)", color: "#854d0e" },
    sent: { background: "var(--editor-success-bg)", color: "var(--editor-success-green)" },
    failed: { background: "var(--editor-danger-bg)", color: "var(--editor-danger)" }
  };
  const s = map[status] ?? map.draft;
  return {
    display: "inline-block",
    padding: "2px 8px",
    fontSize: 11,
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "0.04em",
    borderRadius: 4,
    ...s
  };
}
function Broadcasts() {
  const routes = usePluginRoutes5();
  const [broadcasts, setBroadcasts] = useState5([]);
  const [lists, setLists] = useState5([]);
  const [error, setError] = useState5(null);
  const [loading, setLoading] = useState5(true);
  const [composing, setComposing] = useState5(false);
  const [editBroadcast, setEditBroadcast] = useState5(null);
  const refresh = useCallback4(async () => {
    setLoading(true);
    setError(null);
    try {
      const [bRes, lRes] = await Promise.all([
        routes.fetch("broadcasts"),
        routes.fetch("lists")
      ]);
      const bBody = await bRes.json();
      const lBody = await lRes.json();
      if (bBody.error)
        throw new Error(bBody.error);
      const sorted = [...bBody.broadcasts ?? []].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setBroadcasts(sorted);
      setLists(lBody.lists ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load broadcasts");
    } finally {
      setLoading(false);
    }
  }, [routes]);
  useEffect4(() => {
    refresh();
  }, [refresh]);
  function openNew() {
    setEditBroadcast(null);
    setComposing(true);
  }
  function openEdit(b) {
    setEditBroadcast(b);
    setComposing(true);
  }
  function handleSaved(b) {
    setBroadcasts((prev) => {
      const idx = prev.findIndex((x) => x.id === b.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], ...b };
        return next;
      }
      return [b, ...prev];
    });
  }
  async function handleSend(id) {
    setError(null);
    try {
      const res = await routes.fetch(`broadcasts/${id}/send`, { method: "POST" });
      const body = await res.json();
      if (body.error)
        throw new Error(body.error);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Send failed");
    }
  }
  if (composing) {
    return /* @__PURE__ */ jsxDEV5(BroadcastComposer, {
      lists,
      broadcast: editBroadcast,
      onClose: () => {
        setComposing(false);
        refresh();
      },
      onSaved: handleSaved
    }, undefined, false, undefined, this);
  }
  return /* @__PURE__ */ jsxDEV5(Stack5, {
    gap: 16,
    children: [
      /* @__PURE__ */ jsxDEV5(Stack5, {
        direction: "row",
        gap: 8,
        children: [
          /* @__PURE__ */ jsxDEV5(Heading5, {
            level: 3,
            style: { flex: 1 },
            children: "Broadcasts"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV5(Button4, {
            variant: "primary",
            size: "sm",
            onClick: openNew,
            children: "New broadcast"
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this),
      error && /* @__PURE__ */ jsxDEV5(Alert5, {
        tone: "danger",
        title: "Error",
        role: "alert",
        children: error
      }, undefined, false, undefined, this),
      loading && /* @__PURE__ */ jsxDEV5(Text5, {
        variant: "muted",
        children: "Loading…"
      }, undefined, false, undefined, this),
      !loading && broadcasts.length === 0 && /* @__PURE__ */ jsxDEV5(Alert5, {
        tone: "info",
        title: "No broadcasts yet",
        children: "Create your first broadcast to send a newsletter."
      }, undefined, false, undefined, this),
      broadcasts.map((b) => {
        const openRate = b.recipientCount > 0 ? Math.round(b.openCount / b.recipientCount * 100) : 0;
        const clickRate = b.recipientCount > 0 ? Math.round(b.clickCount / b.recipientCount * 100) : 0;
        const listNames = b.listIds.map((id) => lists.find((l) => l.id === id)?.name ?? id).join(", ");
        return /* @__PURE__ */ jsxDEV5(Card4, {
          padding: 16,
          children: /* @__PURE__ */ jsxDEV5(Stack5, {
            gap: 8,
            children: [
              /* @__PURE__ */ jsxDEV5(Stack5, {
                direction: "row",
                gap: 8,
                children: [
                  /* @__PURE__ */ jsxDEV5(Stack5, {
                    gap: 4,
                    style: { flex: 1 },
                    children: [
                      /* @__PURE__ */ jsxDEV5(Stack5, {
                        direction: "row",
                        gap: 8,
                        children: [
                          /* @__PURE__ */ jsxDEV5(Text5, {
                            children: /* @__PURE__ */ jsxDEV5("strong", {
                              children: b.subject
                            }, undefined, false, undefined, this)
                          }, undefined, false, undefined, this),
                          /* @__PURE__ */ jsxDEV5("span", {
                            style: statusStyle2(b.status),
                            children: b.status
                          }, undefined, false, undefined, this)
                        ]
                      }, undefined, true, undefined, this),
                      /* @__PURE__ */ jsxDEV5(Text5, {
                        variant: "muted",
                        style: { fontSize: 12 },
                        children: [
                          listNames || "All subscribers",
                          b.sentAt && ` · Sent ${new Date(b.sentAt).toLocaleString()}`,
                          b.scheduledAt && !b.sentAt && ` · Scheduled ${new Date(b.scheduledAt).toLocaleString()}`
                        ]
                      }, undefined, true, undefined, this)
                    ]
                  }, undefined, true, undefined, this),
                  /* @__PURE__ */ jsxDEV5(Stack5, {
                    direction: "row",
                    gap: 6,
                    children: [
                      (b.status === "draft" || b.status === "scheduled") && /* @__PURE__ */ jsxDEV5(Fragment3, {
                        children: [
                          /* @__PURE__ */ jsxDEV5(Button4, {
                            variant: "secondary",
                            size: "sm",
                            onClick: () => openEdit(b),
                            children: "Edit"
                          }, undefined, false, undefined, this),
                          /* @__PURE__ */ jsxDEV5(Button4, {
                            variant: "primary",
                            size: "sm",
                            onClick: () => void handleSend(b.id),
                            children: "Send now"
                          }, undefined, false, undefined, this)
                        ]
                      }, undefined, true, undefined, this),
                      b.status === "failed" && /* @__PURE__ */ jsxDEV5(Button4, {
                        variant: "destructive",
                        size: "sm",
                        onClick: () => void handleSend(b.id),
                        children: "Retry"
                      }, undefined, false, undefined, this)
                    ]
                  }, undefined, true, undefined, this)
                ]
              }, undefined, true, undefined, this),
              b.status === "sent" && /* @__PURE__ */ jsxDEV5(Stack5, {
                direction: "row",
                gap: 16,
                children: [
                  /* @__PURE__ */ jsxDEV5(Text5, {
                    variant: "muted",
                    style: { fontSize: 12 },
                    children: [
                      b.recipientCount,
                      " sent"
                    ]
                  }, undefined, true, undefined, this),
                  /* @__PURE__ */ jsxDEV5(Text5, {
                    variant: "muted",
                    style: { fontSize: 12 },
                    children: [
                      b.openCount,
                      " opens (",
                      openRate,
                      "%)"
                    ]
                  }, undefined, true, undefined, this),
                  /* @__PURE__ */ jsxDEV5(Text5, {
                    variant: "muted",
                    style: { fontSize: 12 },
                    children: [
                      b.clickCount,
                      " clicks (",
                      clickRate,
                      "%)"
                    ]
                  }, undefined, true, undefined, this)
                ]
              }, undefined, true, undefined, this)
            ]
          }, undefined, true, undefined, this)
        }, b.id, false, undefined, this);
      })
    ]
  }, undefined, true, undefined, this);
}

// examples/plugins/newsletter/admin/dashboard.tsx
import { jsxDEV as jsxDEV6 } from "react/jsx-dev-runtime";
function NewsletterDashboard() {
  const [activeTab, setActiveTab] = useState6("overview");
  return /* @__PURE__ */ jsxDEV6(Stack6, {
    gap: 24,
    children: [
      /* @__PURE__ */ jsxDEV6(Stack6, {
        gap: 4,
        children: [
          /* @__PURE__ */ jsxDEV6(Heading6, {
            level: 2,
            children: "Newsletter"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV6(Text6, {
            variant: "muted",
            children: [
              "Manage subscribers, lists, and broadcasts. Powered by",
              " ",
              /* @__PURE__ */ jsxDEV6("a", {
                href: "https://resend.com",
                target: "_blank",
                rel: "noopener noreferrer",
                style: { color: "inherit" },
                children: "Resend"
              }, undefined, false, undefined, this),
              "."
            ]
          }, undefined, true, undefined, this)
        ]
      }, undefined, true, undefined, this),
      /* @__PURE__ */ jsxDEV6(Tabs, {
        value: activeTab,
        onChange: setActiveTab,
        children: [
          /* @__PURE__ */ jsxDEV6(TabList, {
            ariaLabel: "Newsletter sections",
            children: [
              /* @__PURE__ */ jsxDEV6(Tab, {
                value: "overview",
                children: "Overview"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV6(Tab, {
                value: "subscribers",
                children: "Subscribers"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV6(Tab, {
                value: "lists",
                children: "Lists"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV6(Tab, {
                value: "broadcasts",
                children: "Broadcasts"
              }, undefined, false, undefined, this)
            ]
          }, undefined, true, undefined, this),
          /* @__PURE__ */ jsxDEV6(TabPanel, {
            value: "overview",
            children: /* @__PURE__ */ jsxDEV6(Stats, {}, undefined, false, undefined, this)
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV6(TabPanel, {
            value: "subscribers",
            children: /* @__PURE__ */ jsxDEV6(Subscribers, {}, undefined, false, undefined, this)
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV6(TabPanel, {
            value: "lists",
            children: /* @__PURE__ */ jsxDEV6(Lists, {}, undefined, false, undefined, this)
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV6(TabPanel, {
            value: "broadcasts",
            children: /* @__PURE__ */ jsxDEV6(Broadcasts, {}, undefined, false, undefined, this)
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this)
    ]
  }, undefined, true, undefined, this);
}
var dashboard_default = definePluginAdminApp(NewsletterDashboard);
export {
  dashboard_default as default
};
