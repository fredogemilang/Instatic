(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // examples/plugins/newsletter/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    generateToken: () => generateToken,
    default: () => server_default
  });

  // examples/plugins/newsletter/server/resend.ts
  function utf8(s) {
    const out = [];
    for (let i = 0;i < s.length; i++) {
      const c = s.charCodeAt(i);
      if (c < 128) {
        out.push(c);
      } else if (c < 2048) {
        out.push(192 | c >> 6, 128 | c & 63);
      } else if (c >= 55296 && c <= 56319) {
        const next = s.charCodeAt(++i);
        const cp = 65536 + ((c & 1023) << 10 | next & 1023);
        out.push(240 | cp >> 18, 128 | cp >> 12 & 63, 128 | cp >> 6 & 63, 128 | cp & 63);
      } else {
        out.push(224 | c >> 12, 128 | c >> 6 & 63, 128 | c & 63);
      }
    }
    return new Uint8Array(out);
  }
  function bytesToHex(bytes) {
    let hex = "";
    for (let i = 0;i < bytes.length; i++)
      hex += bytes[i].toString(16).padStart(2, "0");
    return hex;
  }
  function base64ToBytes(b64) {
    const table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = b64.replace(/=+$/, "").replace(/[^A-Za-z0-9+/]/g, "");
    const output = [];
    let acc = 0;
    let bits = 0;
    for (let i = 0;i < clean.length; i++) {
      const val = table.indexOf(clean[i]);
      if (val < 0)
        continue;
      acc = acc << 6 | val;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        output.push(acc >> bits & 255);
      }
    }
    return new Uint8Array(output);
  }
  async function hmacSha256(key, data) {
    const keyBytes = typeof key === "string" ? utf8(key) : key;
    const cryptoKey = await crypto.subtle.importKey("raw", keyBytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign({ name: "HMAC" }, cryptoKey, utf8(data));
    return bytesToHex(new Uint8Array(sig));
  }
  function generateToken() {
    const t = Date.now().toString(36);
    const r1 = Math.floor(Math.random() * 4294967295).toString(36).padStart(7, "0");
    const r2 = Math.floor(Math.random() * 4294967295).toString(36).padStart(7, "0");
    const r3 = Math.floor(Math.random() * 4294967295).toString(36).padStart(7, "0");
    return `${t}${r1}${r2}${r3}`;
  }
  async function sendEmail(params, apiKey) {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: params.from,
        to: [params.to],
        subject: params.subject,
        html: params.html,
        ...params.text ? { text: params.text } : {}
      }),
      signal: AbortSignal.timeout(15000)
    });
    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Resend API error ${res.status}: ${body}`);
    }
    return await res.json();
  }
  async function sendBatch(messages, apiKey) {
    const res = await fetch("https://api.resend.com/emails/batch", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(messages.map((m) => ({
        from: m.from,
        to: [m.to],
        subject: m.subject,
        html: m.html,
        ...m.text ? { text: m.text } : {}
      }))),
      signal: AbortSignal.timeout(30000)
    });
    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Resend batch API error ${res.status}: ${body}`);
    }
    return await res.json();
  }
  async function verifyWebhookSignature(rawBody, svixId, svixTimestamp, svixSignature, secret) {
    const secretBase64 = secret.startsWith("whsec_") ? secret.slice(6) : secret;
    const secretBytes = base64ToBytes(secretBase64);
    const toSign = `${svixId}.${svixTimestamp}.${rawBody}`;
    const expected = await hmacSha256(secretBytes, toSign);
    const sigs = svixSignature.split(" ");
    for (const sig of sigs) {
      const [, hex] = sig.split(",");
      if (hex === expected)
        return true;
    }
    return false;
  }

  // examples/plugins/newsletter/server/templates.ts
  var BODY_STYLE = "margin:0;padding:0;background:#f5f5f5;font-family:Georgia,serif;color:#222;";
  var CONTAINER_STYLE = "max-width:600px;margin:32px auto;background:#fff;border:1px solid #ddd;border-radius:4px;overflow:hidden;";
  var HEADER_STYLE = "background:#111;padding:24px 32px;";
  var HEADER_TEXT_STYLE = "margin:0;font-size:20px;color:#fff;font-family:Arial,sans-serif;";
  var CONTENT_STYLE = "padding:32px;line-height:1.6;";
  var FOOTER_STYLE = "padding:20px 32px;border-top:1px solid #eee;font-size:12px;color:#999;font-family:Arial,sans-serif;line-height:1.5;";
  var BUTTON_STYLE = "display:inline-block;padding:12px 24px;background:#111;color:#fff;text-decoration:none;border-radius:4px;font-family:Arial,sans-serif;font-size:14px;font-weight:600;margin:16px 0;";
  var LINK_STYLE = "color:#555;text-decoration:underline;";
  function layout(siteName, headingText, body, footer) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(headingText)}</title>
</head>
<body style="${BODY_STYLE}">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0">
<tr><td>
<div style="${CONTAINER_STYLE}">
  <div style="${HEADER_STYLE}">
    <h1 style="${HEADER_TEXT_STYLE}">${esc(siteName)}</h1>
  </div>
  <div style="${CONTENT_STYLE}">${body}</div>
  <div style="${FOOTER_STYLE}">${footer}</div>
</div>
</td></tr>
</table>
</body>
</html>`;
  }
  function esc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function renderOptInEmail(params) {
    const { siteName, confirmUrl, optInBody } = params;
    const processedBody = optInBody.replace(/\{\{confirm_url\}\}/g, confirmUrl);
    const htmlBody = processedBody.includes("<") ? processedBody : `<p>${esc(processedBody)}</p>`;
    const html = layout(siteName, params.subject, `
    ${htmlBody}
    <p><a href="${confirmUrl}" style="${BUTTON_STYLE}">Confirm my subscription</a></p>
    <p style="font-size:13px;color:#888;">Or copy and paste this link into your browser:<br>
    <a href="${confirmUrl}" style="${LINK_STYLE}">${esc(confirmUrl)}</a></p>
    `, `You're receiving this because someone subscribed using your email address.
     If you didn't request this, you can safely ignore this email.`);
    const text = [
      `${siteName} — Please confirm your subscription`,
      "",
      processedBody.replace(/<[^>]+>/g, ""),
      "",
      `Confirm here: ${confirmUrl}`,
      "",
      "If you didn't request this, ignore this email."
    ].join(`
`);
    return { html, text };
  }
  function renderBroadcastEmail(params) {
    const { siteName, subject, htmlBody, plainBody, preferencesUrl, unsubscribeUrl } = params;
    const processedHtml = htmlBody.replace(/\{\{preferences_url\}\}/g, preferencesUrl).replace(/\{\{unsubscribe_url\}\}/g, unsubscribeUrl);
    const footer = `
    <a href="${preferencesUrl}" style="${LINK_STYLE}">Manage preferences</a> &nbsp;·&nbsp;
    <a href="${unsubscribeUrl}" style="${LINK_STYLE}">Unsubscribe</a><br>
    You are receiving this email because you subscribed to ${esc(siteName)}.`;
    const html = layout(siteName, subject, processedHtml, footer);
    const processedPlain = plainBody.replace(/\{\{preferences_url\}\}/g, preferencesUrl).replace(/\{\{unsubscribe_url\}\}/g, unsubscribeUrl);
    const text = [
      processedPlain || plainBody.replace(/<[^>]+>/g, ""),
      "",
      "---",
      `Manage preferences: ${preferencesUrl}`,
      `Unsubscribe: ${unsubscribeUrl}`
    ].join(`
`);
    return { html, text };
  }
  function renderConfirmPage(siteName, email) {
    return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Subscription confirmed</title>
<style>body{font-family:Arial,sans-serif;max-width:480px;margin:80px auto;text-align:center;color:#222}
h1{font-size:1.5rem}p{color:#555}</style></head>
<body>
<h1>You&#39;re subscribed!</h1>
<p>Thank you for confirming your subscription to <strong>${esc(siteName)}</strong>.</p>
<p style="color:#888;font-size:13px">${esc(email)}</p>
</body></html>`;
  }
  function renderUnsubscribePage(siteName, email) {
    return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Unsubscribed</title>
<style>body{font-family:Arial,sans-serif;max-width:480px;margin:80px auto;text-align:center;color:#222}
h1{font-size:1.5rem}p{color:#555}</style></head>
<body>
<h1>You&#39;ve been unsubscribed</h1>
<p>You have been removed from <strong>${esc(siteName)}</strong>&#39;s mailing list.</p>
<p style="color:#888;font-size:13px">${esc(email)}</p>
</body></html>`;
  }
  function renderPreferencesPage(siteName, email, token, runtimeBase, allLists, subscribedListIds) {
    const saveUrl = `${runtimeBase}/preferences/${token}/save`;
    const subscribedSet = new Set(subscribedListIds);
    const checkboxes = allLists.map((list) => `<label style="display:block;margin:8px 0;cursor:pointer">
      <input type="checkbox" name="listId" value="${esc(list.id)}"${subscribedSet.has(list.id) ? " checked" : ""}>
      <strong>${esc(list.name)}</strong>
      ${list.description ? `<span style="color:#888;font-size:13px"> — ${esc(list.description)}</span>` : ""}
    </label>`).join(`
`);
    return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Email preferences</title>
<style>body{font-family:Arial,sans-serif;max-width:480px;margin:60px auto;color:#222;padding:0 16px}
h1{font-size:1.4rem}p{color:#555}
.btn{display:inline-block;padding:10px 20px;background:#111;color:#fff;border:none;border-radius:4px;font-size:14px;cursor:pointer}</style>
</head>
<body>
<h1>Email preferences</h1>
<p>Managing subscriptions for <strong>${esc(email)}</strong> at <strong>${esc(siteName)}</strong>.</p>
<form method="GET" action="${saveUrl}">
  <input type="hidden" name="email" value="${esc(email)}">
  ${checkboxes || '<p style="color:#888">No mailing lists available.</p>'}
  <p><button type="submit" class="btn">Save preferences</button></p>
</form>
<p><a href="${runtimeBase}/unsubscribe?token=${encodeURIComponent(token)}" style="color:#888;font-size:13px">Unsubscribe from all emails</a></p>
</body></html>`;
  }
  function renderPreferencesSavedPage(siteName) {
    return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Preferences saved</title>
<style>body{font-family:Arial,sans-serif;max-width:480px;margin:80px auto;text-align:center;color:#222}</style>
</head>
<body>
<h1>Preferences saved</h1>
<p>Your email preferences for <strong>${esc(siteName)}</strong> have been updated.</p>
</body></html>`;
  }
  function renderAlreadySubscribedPage(siteName) {
    return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Already subscribed</title>
<style>body{font-family:Arial,sans-serif;max-width:480px;margin:80px auto;text-align:center;color:#222}</style>
</head>
<body>
<h1>Already subscribed</h1>
<p>That email address is already subscribed to <strong>${esc(siteName)}</strong>.</p>
</body></html>`;
  }
  function renderErrorPage(message) {
    return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Error</title>
<style>body{font-family:Arial,sans-serif;max-width:480px;margin:80px auto;text-align:center;color:#222}</style>
</head>
<body>
<h1>Something went wrong</h1>
<p>${esc(message)}</p>
</body></html>`;
  }

  // examples/plugins/newsletter/server/csv.ts
  function escapeCsv(val) {
    const s = val == null ? "" : String(val);
    if (s.includes(",") || s.includes('"') || s.includes(`
`) || s.includes("\r")) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  }
  function toCsv(headers, rows) {
    const lines = [headers.map(escapeCsv).join(",")];
    for (const row of rows) {
      lines.push(headers.map((h) => escapeCsv(row[h])).join(","));
    }
    return lines.join(`\r
`);
  }

  // examples/plugins/newsletter/server/subscribe.ts
  function getSegments(req) {
    const url = new URL(req.url);
    const marker = "/runtime/";
    const idx = url.pathname.indexOf(marker);
    const relative = idx >= 0 ? url.pathname.slice(idx + marker.length) : url.pathname;
    return relative.split("/").filter(Boolean);
  }
  function runtimeBase(pluginId, siteUrl) {
    return `${siteUrl}/admin/api/cms/plugins/${pluginId}/runtime`;
  }
  function isValidEmail(s) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
  }
  function htmlResponse(body, status = 200) {
    return {
      __response: true,
      status,
      headers: { "Content-Type": "text/html; charset=utf-8" },
      body
    };
  }
  function redirectResponse(location) {
    return { __response: true, status: 302, headers: { Location: location }, body: "" };
  }
  function registerSubscribeRoutes(api) {
    const subs = api.cms.storage.collection("subscribers");
    const lists = api.cms.storage.collection("lists");
    api.cms.routes.getPublic("/subscribe", async (ctx) => {
      const url = new URL(ctx.req.url);
      const email = url.searchParams.get("email")?.trim() ?? "";
      const name = url.searchParams.get("name")?.trim() ?? "";
      const listIdsRaw = url.searchParams.get("listIds") ?? "";
      const consent = url.searchParams.get("consent");
      const redirect = url.searchParams.get("redirect") ?? "/";
      if (!isValidEmail(email)) {
        return htmlResponse(renderErrorPage("Please enter a valid email address."));
      }
      if (!consent || consent !== "true" && consent !== "1") {
        return htmlResponse(renderErrorPage("You must provide consent to subscribe."));
      }
      const requestedListIds = listIdsRaw ? listIdsRaw.split(",").map((s) => s.trim()).filter(Boolean) : [];
      try {
        const { records: matchingSubs } = await subs.list({ filter: { email: { like: email } }, limit: 1 });
        const existing = matchingSubs[0];
        const siteName = api.cms.settings.get("fromName") ?? "Newsletter";
        if (existing) {
          const data = existing.data;
          if (data.status === "confirmed" || data.status === "pending") {
            return htmlResponse(renderAlreadySubscribedPage(siteName));
          }
          const confirmationToken2 = generateToken();
          const unsubscribeToken2 = data.unsubscribeToken || generateToken();
          const { records: allListRecords2 } = await lists.list();
          const resolvedListIds2 = resolveListIds(requestedListIds, allListRecords2);
          const doubleOptIn2 = api.cms.settings.get("doubleOptIn") ?? true;
          const newStatus = doubleOptIn2 ? "pending" : "confirmed";
          await subs.update(existing.id, {
            name,
            status: newStatus,
            listIds: resolvedListIds2,
            subscribedAt: new Date().toISOString(),
            confirmedAt: doubleOptIn2 ? null : new Date().toISOString(),
            unsubscribedAt: null,
            confirmationToken: confirmationToken2,
            unsubscribeToken: unsubscribeToken2
          });
          if (doubleOptIn2) {
            await sendOptInEmail(api, email, siteName, confirmationToken2);
          }
          await api.cms.hooks.emit("newsletter.subscribed", {
            subscriberId: existing.id,
            email,
            listIds: resolvedListIds2,
            source: "form"
          });
          return redirectResponse(`${redirect}?nl=subscribed`);
        }
        const { records: allListRecords } = await lists.list();
        const resolvedListIds = resolveListIds(requestedListIds, allListRecords);
        const doubleOptIn = api.cms.settings.get("doubleOptIn") ?? true;
        const confirmationToken = generateToken();
        const unsubscribeToken = generateToken();
        const record = await subs.create({
          email,
          name,
          status: doubleOptIn ? "pending" : "confirmed",
          listIds: resolvedListIds,
          source: "form",
          subscribedAt: new Date().toISOString(),
          confirmedAt: doubleOptIn ? null : new Date().toISOString(),
          unsubscribedAt: null,
          confirmationToken,
          unsubscribeToken
        });
        if (doubleOptIn) {
          await sendOptInEmail(api, email, siteName, confirmationToken);
        }
        await api.cms.hooks.emit("newsletter.subscribed", {
          subscriberId: record.id,
          email,
          listIds: resolvedListIds,
          source: "form"
        });
        return redirectResponse(`${redirect}?nl=subscribed`);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Subscription failed";
        console.error("[newsletter] GET /subscribe error:", err);
        return htmlResponse(renderErrorPage(message));
      }
    });
    api.cms.routes.getPublic("/confirm", async (ctx) => {
      const url = new URL(ctx.req.url);
      const token = url.searchParams.get("token") ?? "";
      const siteName = api.cms.settings.get("fromName") ?? "Newsletter";
      if (!token)
        return htmlResponse(renderErrorPage("Invalid confirmation link."));
      try {
        const { records: all } = await subs.list({ filter: { confirmationToken: token }, limit: 1 });
        const record = all[0];
        if (!record)
          return htmlResponse(renderErrorPage("This confirmation link is invalid or has already been used."));
        const data = record.data;
        if (data.status === "confirmed") {
          return htmlResponse(renderConfirmPage(siteName, data.email));
        }
        await subs.update(record.id, {
          status: "confirmed",
          confirmedAt: new Date().toISOString(),
          confirmationToken: ""
        });
        await api.cms.hooks.emit("newsletter.confirmed", {
          subscriberId: record.id,
          email: data.email
        });
        return htmlResponse(renderConfirmPage(siteName, data.email));
      } catch (err) {
        console.error("[newsletter] GET /confirm error:", err);
        return htmlResponse(renderErrorPage("Confirmation failed. Please try again."));
      }
    });
    api.cms.routes.getPublic("/unsubscribe", async (ctx) => {
      const url = new URL(ctx.req.url);
      const token = url.searchParams.get("token") ?? "";
      const siteName = api.cms.settings.get("fromName") ?? "Newsletter";
      if (!token)
        return htmlResponse(renderErrorPage("Invalid unsubscribe link."));
      try {
        const { records: all } = await subs.list({ filter: { unsubscribeToken: token }, limit: 1 });
        const record = all[0];
        if (!record)
          return htmlResponse(renderErrorPage("This unsubscribe link is invalid."));
        const data = record.data;
        if (data.status === "unsubscribed") {
          return htmlResponse(renderUnsubscribePage(siteName, data.email));
        }
        await subs.update(record.id, {
          status: "unsubscribed",
          unsubscribedAt: new Date().toISOString()
        });
        await api.cms.hooks.emit("newsletter.unsubscribed", {
          subscriberId: record.id,
          email: data.email,
          reason: "user"
        });
        return htmlResponse(renderUnsubscribePage(siteName, data.email));
      } catch (err) {
        console.error("[newsletter] GET /unsubscribe error:", err);
        return htmlResponse(renderErrorPage("Unsubscribe failed. Please try again."));
      }
    });
    api.cms.routes.getPublic("/preferences/:token", async (ctx) => {
      const segments = getSegments(ctx.req);
      const token = segments[1] ?? "";
      const siteName = api.cms.settings.get("fromName") ?? "Newsletter";
      const siteUrl = (api.cms.settings.get("siteUrl") ?? "").replace(/\/$/, "");
      if (!token)
        return htmlResponse(renderErrorPage("Invalid preferences link."));
      try {
        const { records: all } = await subs.list({ filter: { unsubscribeToken: token }, limit: 1 });
        const record = all[0];
        if (!record)
          return htmlResponse(renderErrorPage("This preferences link is invalid."));
        const data = record.data;
        const { records: allListRecords } = await lists.list();
        const allLists = allListRecords.map((r) => ({
          id: r.id,
          name: String(r.data.name ?? ""),
          description: String(r.data.description ?? "")
        }));
        return htmlResponse(renderPreferencesPage(siteName, data.email, token, runtimeBase(api.plugin.id, siteUrl), allLists, data.listIds));
      } catch (err) {
        console.error("[newsletter] GET /preferences error:", err);
        return htmlResponse(renderErrorPage("Failed to load preferences."));
      }
    });
    api.cms.routes.getPublic("/preferences/:token/save", async (ctx) => {
      const segments = getSegments(ctx.req);
      const token = segments[1] ?? "";
      const url = new URL(ctx.req.url);
      const selectedListIds = url.searchParams.getAll("listId");
      const siteName = api.cms.settings.get("fromName") ?? "Newsletter";
      if (!token)
        return htmlResponse(renderErrorPage("Invalid preferences link."));
      try {
        const { records: all } = await subs.list({ filter: { unsubscribeToken: token }, limit: 1 });
        const record = all[0];
        if (!record)
          return htmlResponse(renderErrorPage("This preferences link is invalid."));
        await subs.update(record.id, { listIds: selectedListIds });
        return htmlResponse(renderPreferencesSavedPage(siteName));
      } catch (err) {
        console.error("[newsletter] GET /preferences/save error:", err);
        return htmlResponse(renderErrorPage("Failed to save preferences."));
      }
    });
    api.cms.routes.get("/subscribers", "plugins.manage", async (ctx) => {
      try {
        const url = new URL(ctx.req.url);
        const statusFilter = url.searchParams.get("status") ?? "";
        const listIdFilter = url.searchParams.get("listId") ?? "";
        const searchParam = url.searchParams.get("search") ?? "";
        const limit = Math.min(Math.max(parseInt(url.searchParams.get("limit") ?? "20", 10), 1), 1000);
        const offset = Math.max(parseInt(url.searchParams.get("offset") ?? "0", 10), 0);
        const filter = {};
        if (statusFilter)
          filter.status = statusFilter;
        if (searchParam)
          filter.email = { like: `%${searchParam}%` };
        const { records, totalCount } = await subs.list({ filter, limit, offset });
        let subscribers = records.map((r) => {
          const d = r.data;
          return {
            id: r.id,
            email: d.email,
            name: d.name,
            status: d.status,
            listIds: d.listIds,
            source: d.source,
            subscribedAt: d.subscribedAt,
            confirmedAt: d.confirmedAt,
            unsubscribedAt: d.unsubscribedAt
          };
        });
        if (listIdFilter) {
          subscribers = subscribers.filter((s) => s.listIds.includes(listIdFilter));
        }
        return { ok: true, subscribers, totalCount };
      } catch (err) {
        console.error("[newsletter] GET /subscribers error:", err);
        return { error: err instanceof Error ? err.message : "Failed to list subscribers" };
      }
    });
    api.cms.routes.post("/subscribers", "plugins.manage", async (ctx) => {
      try {
        const body = ctx.body;
        const email = String(body.email ?? "").trim();
        const name = String(body.name ?? "").trim();
        const listIds = Array.isArray(body.listIds) ? body.listIds.map(String) : [];
        if (!isValidEmail(email))
          return { error: "Invalid email address" };
        const { records: matchingSubs } = await subs.list({ filter: { email: { like: email } }, limit: 1 });
        if (matchingSubs.length > 0)
          return { error: "Subscriber already exists" };
        const record = await subs.create({
          email,
          name,
          status: "confirmed",
          listIds,
          source: "admin",
          subscribedAt: new Date().toISOString(),
          confirmedAt: new Date().toISOString(),
          unsubscribedAt: null,
          confirmationToken: "",
          unsubscribeToken: generateToken()
        });
        await api.cms.hooks.emit("newsletter.subscribed", {
          subscriberId: record.id,
          email,
          listIds,
          source: "admin"
        });
        return { ok: true, subscriber: { id: record.id, email, name, status: "confirmed", listIds } };
      } catch (err) {
        console.error("[newsletter] POST /subscribers error:", err);
        return { error: err instanceof Error ? err.message : "Failed to create subscriber" };
      }
    });
    api.cms.routes.delete("/subscribers/:id", "plugins.manage", async (ctx) => {
      try {
        const segments = getSegments(ctx.req);
        const id = segments[1] ?? "";
        if (!id)
          return { error: "Missing subscriber id" };
        const ok = await subs.delete(id);
        return { ok };
      } catch (err) {
        console.error("[newsletter] DELETE /subscribers/:id error:", err);
        return { error: err instanceof Error ? err.message : "Failed to delete subscriber" };
      }
    });
    api.cms.routes.get("/subscribers.csv", "plugins.manage", async () => {
      try {
        const { records: all } = await subs.list({ limit: 1000 });
        const headers = ["id", "email", "name", "status", "listIds", "subscribedAt", "confirmedAt"];
        const rows = all.map((r) => {
          const d = r.data;
          return {
            id: r.id,
            email: d.email,
            name: d.name,
            status: d.status,
            listIds: (d.listIds ?? []).join(";"),
            subscribedAt: d.subscribedAt,
            confirmedAt: d.confirmedAt ?? ""
          };
        });
        const csv = toCsv(headers, rows);
        return {
          __response: true,
          status: 200,
          headers: {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": 'attachment; filename="subscribers.csv"'
          },
          body: csv
        };
      } catch (err) {
        console.error("[newsletter] GET /subscribers.csv error:", err);
        return { error: err instanceof Error ? err.message : "Export failed" };
      }
    });
    api.cms.routes.get("/stats", "plugins.manage", async () => {
      try {
        const { records: allSubs, totalCount: totalSubs } = await subs.list({ limit: 1000 });
        const counts = { pending: 0, confirmed: 0, unsubscribed: 0, bounced: 0 };
        for (const r of allSubs) {
          const s = r.data.status;
          counts[s] = (counts[s] ?? 0) + 1;
        }
        const broadcasts = api.cms.storage.collection("broadcasts");
        const { records: allBroadcasts, totalCount: totalBroadcasts } = await broadcasts.list({ limit: 1000 });
        const bcastCounts = { draft: 0, scheduled: 0, sending: 0, sent: 0, failed: 0 };
        for (const r of allBroadcasts) {
          const s = String(r.data.status ?? "draft");
          bcastCounts[s] = (bcastCounts[s] ?? 0) + 1;
        }
        const deliveries = api.cms.storage.collection("deliveries");
        const { records: allDeliveries, totalCount: totalDeliveries } = await deliveries.list({ limit: 1000 });
        const openedDeliveries = allDeliveries.filter((r) => r.data.openedAt).length;
        const clickedDeliveries = allDeliveries.filter((r) => r.data.clickedAt).length;
        return {
          ok: true,
          subscribers: {
            total: totalSubs,
            ...counts
          },
          broadcasts: {
            total: totalBroadcasts,
            ...bcastCounts
          },
          deliveries: {
            total: totalDeliveries,
            opened: openedDeliveries,
            clicked: clickedDeliveries
          }
        };
      } catch (err) {
        console.error("[newsletter] GET /stats error:", err);
        return { error: err instanceof Error ? err.message : "Failed to load stats" };
      }
    });
    api.cms.routes.get("/lists", "plugins.manage", async () => {
      try {
        const { records: all } = await lists.list();
        return {
          ok: true,
          lists: all.map((r) => ({
            id: r.id,
            name: r.data.name,
            description: r.data.description,
            isDefault: r.data.isDefault,
            createdAt: r.createdAt
          }))
        };
      } catch (err) {
        console.error("[newsletter] GET /lists error:", err);
        return { error: err instanceof Error ? err.message : "Failed to list lists" };
      }
    });
    api.cms.routes.post("/lists", "plugins.manage", async (ctx) => {
      try {
        const body = ctx.body;
        const name = String(body.name ?? "").trim();
        if (!name)
          return { error: "List name is required" };
        const record = await lists.create({
          name,
          description: String(body.description ?? "").trim(),
          isDefault: body.isDefault === true
        });
        return { ok: true, list: { id: record.id, name, description: record.data.description, isDefault: record.data.isDefault } };
      } catch (err) {
        console.error("[newsletter] POST /lists error:", err);
        return { error: err instanceof Error ? err.message : "Failed to create list" };
      }
    });
    api.cms.routes.patch("/lists/:id", "plugins.manage", async (ctx) => {
      try {
        const segments = getSegments(ctx.req);
        const id = segments[1] ?? "";
        if (!id)
          return { error: "Missing list id" };
        const body = ctx.body;
        const updated = await lists.update(id, {
          ...body.name !== undefined ? { name: String(body.name).trim() } : {},
          ...body.description !== undefined ? { description: String(body.description).trim() } : {},
          ...body.isDefault !== undefined ? { isDefault: body.isDefault === true } : {}
        });
        return { ok: true, list: updated?.data ?? null };
      } catch (err) {
        console.error("[newsletter] PATCH /lists/:id error:", err);
        return { error: err instanceof Error ? err.message : "Failed to update list" };
      }
    });
    api.cms.routes.delete("/lists/:id", "plugins.manage", async (ctx) => {
      try {
        const segments = getSegments(ctx.req);
        const id = segments[1] ?? "";
        if (!id)
          return { error: "Missing list id" };
        const ok = await lists.delete(id);
        return { ok };
      } catch (err) {
        console.error("[newsletter] DELETE /lists/:id error:", err);
        return { error: err instanceof Error ? err.message : "Failed to delete list" };
      }
    });
  }
  function resolveListIds(requested, allListRecords) {
    if (requested.length > 0)
      return requested;
    const defaultList = allListRecords.find((r) => r.data.isDefault);
    return defaultList ? [defaultList.id] : [];
  }
  async function sendOptInEmail(api, email, siteName, confirmationToken) {
    const apiKey = api.cms.settings.get("resendApiKey") ?? "";
    const fromAddress = api.cms.settings.get("fromAddress") ?? "";
    const fromName = api.cms.settings.get("fromName") ?? siteName;
    const siteUrl = (api.cms.settings.get("siteUrl") ?? "").replace(/\/$/, "");
    const subject = api.cms.settings.get("optInEmailSubject") ?? "Please confirm your subscription";
    const body = api.cms.settings.get("optInEmailBody") ?? "Click the link below to confirm: {{confirm_url}}";
    if (!apiKey || !fromAddress) {
      api.plugin.log("[newsletter] sendOptInEmail: resendApiKey or fromAddress not configured");
      return;
    }
    const confirmUrl = `${siteUrl}/admin/api/cms/plugins/${api.plugin.id}/runtime/confirm?token=${encodeURIComponent(confirmationToken)}`;
    const { html, text } = renderOptInEmail({ siteName, confirmUrl, subject, optInBody: body });
    try {
      await sendEmail({ to: email, subject, html, text, from: `${fromName} <${fromAddress}>` }, apiKey);
    } catch (err) {
      api.plugin.log("[newsletter] Failed to send opt-in email:", err instanceof Error ? err.message : String(err));
    }
  }

  // examples/plugins/newsletter/server/broadcasts.ts
  function getSegments2(req) {
    const url = new URL(req.url);
    const marker = "/runtime/";
    const idx = url.pathname.indexOf(marker);
    const relative = idx >= 0 ? url.pathname.slice(idx + marker.length) : url.pathname;
    return relative.split("/").filter(Boolean);
  }
  function registerBroadcastRoutes(api) {
    const broadcasts = api.cms.storage.collection("broadcasts");
    const subs = api.cms.storage.collection("subscribers");
    const deliveries = api.cms.storage.collection("deliveries");
    api.cms.routes.get("/broadcasts", "plugins.manage", async () => {
      try {
        const { records: all } = await broadcasts.list();
        return {
          ok: true,
          broadcasts: all.map((r) => {
            const d = r.data;
            return {
              id: r.id,
              subject: d.subject,
              status: d.status,
              scheduledAt: d.scheduledAt,
              sentAt: d.sentAt,
              listIds: d.listIds,
              recipientCount: d.recipientCount,
              openCount: d.openCount,
              clickCount: d.clickCount,
              createdAt: r.createdAt
            };
          })
        };
      } catch (err) {
        console.error("[newsletter] GET /broadcasts error:", err);
        return { error: err instanceof Error ? err.message : "Failed to list broadcasts" };
      }
    });
    api.cms.routes.post("/broadcasts", "plugins.manage", async (ctx) => {
      try {
        const body = ctx.body;
        const subject = String(body.subject ?? "").trim();
        if (!subject)
          return { error: "Subject is required" };
        const record = await broadcasts.create({
          subject,
          htmlBody: String(body.htmlBody ?? ""),
          plainBody: String(body.plainBody ?? ""),
          listIds: Array.isArray(body.listIds) ? body.listIds.map(String) : [],
          status: "draft",
          scheduledAt: null,
          sentAt: null,
          recipientCount: 0,
          openCount: 0,
          clickCount: 0
        });
        return { ok: true, broadcast: { id: record.id, ...record.data } };
      } catch (err) {
        console.error("[newsletter] POST /broadcasts error:", err);
        return { error: err instanceof Error ? err.message : "Failed to create broadcast" };
      }
    });
    api.cms.routes.patch("/broadcasts/:id", "plugins.manage", async (ctx) => {
      try {
        const segments = getSegments2(ctx.req);
        const id = segments[1] ?? "";
        if (!id)
          return { error: "Missing broadcast id" };
        const body = ctx.body;
        const patch = {};
        if (body.subject !== undefined)
          patch.subject = String(body.subject).trim();
        if (body.htmlBody !== undefined)
          patch.htmlBody = String(body.htmlBody);
        if (body.plainBody !== undefined)
          patch.plainBody = String(body.plainBody);
        if (body.listIds !== undefined)
          patch.listIds = Array.isArray(body.listIds) ? body.listIds.map(String) : [];
        if (body.scheduledAt !== undefined) {
          patch.scheduledAt = body.scheduledAt ? String(body.scheduledAt) : null;
          patch.status = body.scheduledAt ? "scheduled" : "draft";
        }
        const updated = await broadcasts.update(id, patch);
        return { ok: true, broadcast: updated?.data ?? null };
      } catch (err) {
        console.error("[newsletter] PATCH /broadcasts/:id error:", err);
        return { error: err instanceof Error ? err.message : "Failed to update broadcast" };
      }
    });
    api.cms.routes.post("/broadcasts/:id/send", "plugins.manage", async (ctx) => {
      try {
        const segments = getSegments2(ctx.req);
        const id = segments[1] ?? "";
        if (!id)
          return { error: "Missing broadcast id" };
        const result = await executeSend(id, api, broadcasts, subs, deliveries);
        return result;
      } catch (err) {
        console.error("[newsletter] POST /broadcasts/:id/send error:", err);
        return { error: err instanceof Error ? err.message : "Send failed" };
      }
    });
    api.cms.routes.post("/broadcasts/:id/preview", "plugins.manage", async (ctx) => {
      try {
        const segments = getSegments2(ctx.req);
        const id = segments[1] ?? "";
        if (!id)
          return { error: "Missing broadcast id" };
        const toEmail = String(ctx.body.email ?? "").trim();
        if (!toEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(toEmail)) {
          return { error: "Valid email address required" };
        }
        const { records: allBroadcasts } = await broadcasts.list();
        const bRecord = allBroadcasts.find((r) => r.id === id);
        if (!bRecord)
          return { error: "Broadcast not found" };
        const d = bRecord.data;
        const apiKey = api.cms.settings.get("resendApiKey") ?? "";
        const fromAddress = api.cms.settings.get("fromAddress") ?? "";
        const fromName = api.cms.settings.get("fromName") ?? "";
        const siteUrl = (api.cms.settings.get("siteUrl") ?? "").replace(/\/$/, "");
        const runtimeBase2 = `${siteUrl}/admin/api/cms/plugins/${api.plugin.id}/runtime`;
        if (!apiKey || !fromAddress)
          return { error: "Resend API key or from address not configured" };
        const { html, text } = renderBroadcastEmail({
          siteName: fromName,
          subject: `[PREVIEW] ${d.subject}`,
          htmlBody: d.htmlBody,
          plainBody: d.plainBody,
          preferencesUrl: `${runtimeBase2}/preferences/preview-token`,
          unsubscribeUrl: `${runtimeBase2}/unsubscribe?token=preview-token`
        });
        await sendEmail({ to: toEmail, subject: `[PREVIEW] ${d.subject}`, html, text, from: `${fromName} <${fromAddress}>` }, apiKey);
        return { ok: true };
      } catch (err) {
        console.error("[newsletter] POST /broadcasts/:id/preview error:", err);
        return { error: err instanceof Error ? err.message : "Preview send failed" };
      }
    });
  }
  function registerBroadcastSchedule(api) {
    const broadcasts = api.cms.storage.collection("broadcasts");
    const subs = api.cms.storage.collection("subscribers");
    const deliveries = api.cms.storage.collection("deliveries");
    api.cms.schedule.register({
      id: "send-scheduled",
      cadence: { interval: "every", minutes: 5 },
      overlap: "skip",
      maxDurationMs: 120000,
      handler: async () => {
        const now = new Date().toISOString();
        const { records: due } = await broadcasts.list({
          filter: { status: "scheduled", scheduledAt: { lte: now } }
        });
        for (const bRecord of due) {
          try {
            await executeSend(bRecord.id, api, broadcasts, subs, deliveries);
          } catch (err) {
            api.plugin.log("[newsletter] Scheduled send failed for broadcast", bRecord.id, err instanceof Error ? err.message : String(err));
          }
        }
      }
    });
  }
  async function executeSend(broadcastId, api, broadcasts, subs, deliveries) {
    const { records: allBroadcasts } = await broadcasts.list();
    const bRecord = allBroadcasts.find((r) => r.id === broadcastId);
    if (!bRecord)
      return { error: "Broadcast not found" };
    const d = bRecord.data;
    if (d.status === "sending" || d.status === "sent") {
      return { error: `Broadcast is already in status "${d.status}"` };
    }
    await broadcasts.update(broadcastId, { status: "sending" });
    const apiKey = api.cms.settings.get("resendApiKey") ?? "";
    const fromAddress = api.cms.settings.get("fromAddress") ?? "";
    const fromName = api.cms.settings.get("fromName") ?? "";
    const siteUrl = (api.cms.settings.get("siteUrl") ?? "").replace(/\/$/, "");
    const runtimeBase2 = `${siteUrl}/admin/api/cms/plugins/${api.plugin.id}/runtime`;
    if (!apiKey || !fromAddress) {
      await broadcasts.update(broadcastId, { status: "draft" });
      return { error: "Resend API key or from address not configured" };
    }
    const { records: confirmedSubs } = await subs.list({
      filter: { status: "confirmed" },
      limit: 1000
    });
    const targetSubs = confirmedSubs.filter((r) => {
      const sub = r.data;
      if (d.listIds.length === 0)
        return true;
      return d.listIds.some((lid) => sub.listIds.includes(lid));
    });
    let sentCount = 0;
    let failed = false;
    const BATCH_SIZE = 50;
    try {
      for (let i = 0;i < targetSubs.length; i += BATCH_SIZE) {
        const chunk = targetSubs.slice(i, i + BATCH_SIZE);
        const messages = chunk.map((subRecord) => {
          const sub = subRecord.data;
          const preferencesUrl = `${runtimeBase2}/preferences/${sub.unsubscribeToken}`;
          const unsubscribeUrl = `${runtimeBase2}/unsubscribe?token=${encodeURIComponent(sub.unsubscribeToken)}`;
          const { html, text } = renderBroadcastEmail({
            siteName: fromName,
            subject: d.subject,
            htmlBody: d.htmlBody,
            plainBody: d.plainBody,
            preferencesUrl,
            unsubscribeUrl
          });
          return {
            to: sub.email,
            subject: d.subject,
            html,
            text,
            from: `${fromName} <${fromAddress}>`,
            subscriberId: subRecord.id
          };
        });
        const batchPayload = messages.map(({ subscriberId: _s, ...m }) => m);
        let batchResult;
        try {
          batchResult = await sendBatch(batchPayload, apiKey);
        } catch (err) {
          api.plugin.log("[newsletter] Batch send failed:", err instanceof Error ? err.message : String(err));
          failed = true;
          break;
        }
        const now = new Date().toISOString();
        for (let j = 0;j < chunk.length; j++) {
          const resendId = batchResult.data[j]?.id ?? null;
          await deliveries.create({
            broadcastId,
            subscriberId: messages[j].subscriberId,
            sentAt: now,
            openedAt: null,
            clickedAt: null,
            bounced: false,
            resendId
          });
        }
        sentCount += chunk.length;
      }
    } catch (err) {
      api.plugin.log("[newsletter] executeSend error:", err instanceof Error ? err.message : String(err));
      failed = true;
    }
    const finalStatus = failed ? "failed" : "sent";
    await broadcasts.update(broadcastId, {
      status: finalStatus,
      sentAt: new Date().toISOString(),
      recipientCount: sentCount
    });
    if (!failed) {
      await api.cms.hooks.emit("newsletter.broadcast.sent", {
        broadcastId,
        recipientCount: sentCount,
        listIds: d.listIds
      });
    }
    return { ok: !failed, status: finalStatus, recipientCount: sentCount };
  }

  // examples/plugins/newsletter/server/webhooks.ts
  function registerWebhookRoutes(api) {
    api.cms.routes.postPublic("/webhooks/resend", async (ctx) => {
      try {
        const secret = api.cms.settings.get("resendWebhookSecret") ?? "";
        if (!secret) {
          api.plugin.log("[newsletter] webhook: resendWebhookSecret not configured, rejecting");
          return { __response: true, status: 400, headers: {}, body: "Webhook secret not configured" };
        }
        const svixId = ctx.req.headers.get("svix-id") ?? "";
        const svixTimestamp = ctx.req.headers.get("svix-timestamp") ?? "";
        const svixSignature = ctx.req.headers.get("svix-signature") ?? "";
        let rawBody;
        try {
          rawBody = await ctx.req.text();
        } catch (_err) {
          rawBody = JSON.stringify(ctx.body);
        }
        if (svixId && svixTimestamp && svixSignature) {
          const valid = await verifyWebhookSignature(rawBody, svixId, svixTimestamp, svixSignature, secret);
          if (!valid) {
            api.plugin.log("[newsletter] webhook: signature verification failed");
            return { __response: true, status: 401, headers: {}, body: "Invalid signature" };
          }
        }
        const event = ctx.body;
        const eventType = String(event.type ?? "");
        const data = event.data ?? {};
        api.plugin.log("[newsletter] webhook event:", eventType);
        await handleWebhookEvent(eventType, data, api);
        return { ok: true };
      } catch (err) {
        console.error("[newsletter] POST /webhooks/resend error:", err);
        return { error: err instanceof Error ? err.message : "Webhook processing failed" };
      }
    });
  }
  async function handleWebhookEvent(eventType, data, api) {
    const resendId = String(data.email_id ?? data.id ?? "");
    const deliveries = api.cms.storage.collection("deliveries");
    const subs = api.cms.storage.collection("subscribers");
    const broadcasts = api.cms.storage.collection("broadcasts");
    const { records: deliveryRecords } = await deliveries.list({ filter: { resendId }, limit: 1 });
    const delivery = deliveryRecords[0];
    switch (eventType) {
      case "email.bounced": {
        if (delivery) {
          await deliveries.update(delivery.id, { bounced: true });
          await incrementBroadcastCounter(broadcasts, String(delivery.data.broadcastId ?? ""), "openCount", 0);
        }
        const toEmail = String(data.to ?? "");
        if (toEmail) {
          const { records: subRecords } = await subs.list({ filter: { email: { like: toEmail } }, limit: 1 });
          const sub = subRecords[0];
          if (sub) {
            await subs.update(sub.id, { status: "bounced" });
            await api.cms.hooks.emit("newsletter.unsubscribed", {
              subscriberId: sub.id,
              email: toEmail,
              reason: "bounced"
            });
          }
        }
        break;
      }
      case "email.complained": {
        const toEmail = String(data.to ?? "");
        if (toEmail) {
          const { records: subRecords } = await subs.list({ filter: { email: { like: toEmail } }, limit: 1 });
          const sub = subRecords[0];
          if (sub) {
            await subs.update(sub.id, { status: "unsubscribed", unsubscribedAt: new Date().toISOString() });
            await api.cms.hooks.emit("newsletter.unsubscribed", {
              subscriberId: sub.id,
              email: toEmail,
              reason: "complained"
            });
          }
        }
        break;
      }
      case "email.opened": {
        if (delivery && !delivery.data.openedAt) {
          await deliveries.update(delivery.id, { openedAt: new Date().toISOString() });
          await incrementBroadcastCounter(broadcasts, String(delivery.data.broadcastId ?? ""), "openCount", 1);
        }
        break;
      }
      case "email.clicked": {
        if (delivery && !delivery.data.clickedAt) {
          await deliveries.update(delivery.id, { clickedAt: new Date().toISOString() });
          await incrementBroadcastCounter(broadcasts, String(delivery.data.broadcastId ?? ""), "clickCount", 1);
        }
        break;
      }
      default:
        api.plugin.log("[newsletter] webhook: unhandled event type", eventType);
    }
  }
  async function incrementBroadcastCounter(broadcasts, broadcastId, field, delta) {
    if (!broadcastId || delta === 0)
      return;
    const { records: all } = await broadcasts.list();
    const bRecord = all.find((r) => r.id === broadcastId);
    if (!bRecord)
      return;
    const current = Number(bRecord.data[field] ?? 0);
    await broadcasts.update(broadcastId, { [field]: current + delta });
  }

  // examples/plugins/newsletter/server/index.ts
  var mod = {
    async install(api) {
      api.plugin.log("Newsletter plugin installed — seeding default list.");
      const lists = api.cms.storage.collection("lists");
      const { records: existing } = await lists.list();
      if (existing.length === 0) {
        await lists.create({
          name: "General",
          description: "Main newsletter list.",
          isDefault: true
        });
        api.plugin.log('Newsletter plugin: seeded "General" list.');
      }
    },
    async activate(api) {
      api.plugin.log("Newsletter plugin activating.");
      registerSubscribeRoutes(api);
      registerBroadcastRoutes(api);
      registerWebhookRoutes(api);
      registerBroadcastSchedule(api);
      api.cms.hooks.on("settings.changed", (payload) => {
        if (payload.pluginId !== api.plugin.id)
          return;
        api.plugin.log("Newsletter plugin settings updated.");
      });
      api.plugin.log("Newsletter plugin activated.");
    },
    deactivate(api) {
      api.plugin.log("Newsletter plugin deactivated.");
    },
    async uninstall(api) {
      const collections = ["subscribers", "lists", "broadcasts", "deliveries"];
      for (const name of collections) {
        const col = api.cms.storage.collection(name);
        const { records: all } = await col.list({ limit: 1000 });
        await Promise.all(all.map((r) => col.delete(r.id)));
        api.plugin.log(`Newsletter plugin removed ${all.length} ${name} records.`);
      }
      api.plugin.log("Newsletter plugin uninstalled.");
    }
  };
  var server_default = mod;

  // examples/plugins/newsletter/server/__sandbox-facade-1779306547509.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
