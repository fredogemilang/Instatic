// examples/plugins/seo-suite/admin/dashboard.tsx
import { useCallback, useEffect, useState } from "react";
import {
  Alert,
  Button,
  Card,
  EmptyState,
  Heading,
  Input,
  Stack,
  StatValue,
  Switch,
  Text,
  Textarea
} from "@pagebuilder/host-ui";
import { usePluginRoutes } from "@pagebuilder/host-hooks";
import { definePluginAdminApp } from "@pagebuilder/plugin-sdk";
import { jsxDEV } from "react/jsx-dev-runtime";
function StatCard({ label, value, detail }) {
  return /* @__PURE__ */ jsxDEV(Card, {
    padding: 16,
    children: /* @__PURE__ */ jsxDEV(Stack, {
      gap: 4,
      children: [
        /* @__PURE__ */ jsxDEV(Text, {
          variant: "muted",
          children: label
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(StatValue, {
          value,
          sub: detail ? /* @__PURE__ */ jsxDEV("span", {
            children: detail
          }, undefined, false, undefined, this) : undefined
        }, undefined, false, undefined, this)
      ]
    }, undefined, true, undefined, this)
  }, undefined, false, undefined, this);
}
function StatusBadge({ tone, label }) {
  const colors = {
    success: { bg: "var(--editor-success-bg)", text: "var(--editor-success-green)" },
    warning: { bg: "var(--editor-warning-bg, rgba(251,188,4,0.12))", text: "var(--editor-warning)" },
    danger: { bg: "var(--editor-danger-bg)", text: "var(--editor-danger)" },
    muted: { bg: "var(--panel-border)", text: "var(--editor-text-muted)" }
  };
  const c = colors[tone];
  return /* @__PURE__ */ jsxDEV("span", {
    style: {
      display: "inline-block",
      padding: "2px 8px",
      fontSize: 11,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.04em",
      borderRadius: 4,
      background: c.bg,
      color: c.text
    },
    children: label
  }, undefined, false, undefined, this);
}
function EntryEditor({ pageId, initial, onSave, onCancel }) {
  const [form, setForm] = useState({ ...initial, "page-id": pageId });
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }
  async function handleSave() {
    setSaving(true);
    setSaveError(null);
    try {
      await onSave(form);
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxDEV(Card, {
    padding: 16,
    children: /* @__PURE__ */ jsxDEV(Stack, {
      gap: 12,
      children: [
        /* @__PURE__ */ jsxDEV(Heading, {
          level: 4,
          children: [
            "Edit SEO — ",
            pageId
          ]
        }, undefined, true, undefined, this),
        saveError && /* @__PURE__ */ jsxDEV(Alert, {
          tone: "danger",
          title: "Save failed",
          children: saveError
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Input, {
          label: "Title override",
          value: form["title-override"] ?? "",
          placeholder: "Leave blank to use the page's <title>",
          onChange: (v) => update("title-override", v)
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Textarea, {
          label: "Meta description",
          value: form["meta-description"] ?? "",
          placeholder: "160 character summary for search results",
          rows: 3,
          onChange: (v) => update("meta-description", v)
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Input, {
          label: "OG title",
          value: form["og-title"] ?? "",
          placeholder: "Social card title (defaults to title override)",
          onChange: (v) => update("og-title", v)
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Textarea, {
          label: "OG description",
          value: form["og-description"] ?? "",
          placeholder: "Social card description",
          rows: 2,
          onChange: (v) => update("og-description", v)
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Input, {
          label: "OG image URL",
          value: form["og-image-url"] ?? "",
          placeholder: "https://example.com/og.png",
          onChange: (v) => update("og-image-url", v)
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Input, {
          label: "Twitter card type",
          value: form["twitter-card"] ?? "summary_large_image",
          placeholder: "summary_large_image",
          onChange: (v) => update("twitter-card", v)
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Input, {
          label: "Canonical URL",
          value: form["canonical-url"] ?? "",
          placeholder: "https://example.com/page",
          onChange: (v) => update("canonical-url", v)
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Textarea, {
          label: "Custom JSON-LD (optional)",
          value: form["json-ld"] ?? "",
          placeholder: '{"@context":"https://schema.org","@type":"Article",...}',
          rows: 4,
          onChange: (v) => update("json-ld", v)
        }, undefined, false, undefined, this),
        /* @__PURE__ */ jsxDEV(Stack, {
          direction: "row",
          gap: 8,
          children: [
            /* @__PURE__ */ jsxDEV(Switch, {
              label: "No-index",
              checked: Boolean(form["no-index"]),
              description: "Prevent search engines from indexing this page.",
              onChange: (v) => update("no-index", v)
            }, undefined, false, undefined, this),
            /* @__PURE__ */ jsxDEV(Switch, {
              label: "No-follow",
              checked: Boolean(form["no-follow"]),
              description: "Tell crawlers not to follow links on this page.",
              onChange: (v) => update("no-follow", v)
            }, undefined, false, undefined, this)
          ]
        }, undefined, true, undefined, this),
        /* @__PURE__ */ jsxDEV(Stack, {
          direction: "row",
          gap: 8,
          children: [
            /* @__PURE__ */ jsxDEV(Button, {
              variant: "primary",
              size: "sm",
              onClick: () => void handleSave(),
              disabled: saving,
              children: saving ? "Saving…" : "Save"
            }, undefined, false, undefined, this),
            /* @__PURE__ */ jsxDEV(Button, {
              variant: "secondary",
              size: "sm",
              onClick: onCancel,
              disabled: saving,
              children: "Cancel"
            }, undefined, false, undefined, this)
          ]
        }, undefined, true, undefined, this)
      ]
    }, undefined, true, undefined, this)
  }, undefined, false, undefined, this);
}
function PageRow({ row, expanded, onToggle, onSave }) {
  const entry = row.seoEntry ?? {};
  const hasDesc = Boolean(entry["meta-description"]);
  const hasOg = Boolean(entry["og-image-url"]);
  const noIndex = Boolean(entry["no-index"]);
  return /* @__PURE__ */ jsxDEV(Stack, {
    gap: 8,
    children: [
      /* @__PURE__ */ jsxDEV(Card, {
        padding: 12,
        children: /* @__PURE__ */ jsxDEV(Stack, {
          direction: "row",
          gap: 12,
          align: "center",
          children: [
            /* @__PURE__ */ jsxDEV(Stack, {
              gap: 2,
              style: { flex: 1, minWidth: 0 },
              children: [
                /* @__PURE__ */ jsxDEV(Text, {
                  variant: "strong",
                  children: row.title || row.pageId
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(Text, {
                  variant: "muted",
                  children: row.slug || row.url || row.pageId
                }, undefined, false, undefined, this)
              ]
            }, undefined, true, undefined, this),
            /* @__PURE__ */ jsxDEV(Stack, {
              direction: "row",
              gap: 4,
              align: "center",
              wrap: true,
              children: [
                /* @__PURE__ */ jsxDEV(StatusBadge, {
                  tone: hasDesc ? "success" : "warning",
                  label: hasDesc ? "Has desc" : "No desc"
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(StatusBadge, {
                  tone: hasOg ? "success" : "warning",
                  label: hasOg ? "Has OG" : "No OG"
                }, undefined, false, undefined, this),
                noIndex ? /* @__PURE__ */ jsxDEV(StatusBadge, {
                  tone: "danger",
                  label: "no-index"
                }, undefined, false, undefined, this) : /* @__PURE__ */ jsxDEV(StatusBadge, {
                  tone: "success",
                  label: "indexable"
                }, undefined, false, undefined, this)
              ]
            }, undefined, true, undefined, this),
            /* @__PURE__ */ jsxDEV(Button, {
              variant: "ghost",
              size: "sm",
              onClick: onToggle,
              children: expanded ? "Close" : "Edit SEO"
            }, undefined, false, undefined, this)
          ]
        }, undefined, true, undefined, this)
      }, undefined, false, undefined, this),
      expanded && /* @__PURE__ */ jsxDEV(EntryEditor, {
        pageId: row.pageId,
        initial: entry,
        onSave,
        onCancel: onToggle
      }, undefined, false, undefined, this)
    ]
  }, undefined, true, undefined, this);
}
function SeoSuiteDashboard() {
  const routes = usePluginRoutes();
  const [entries, setEntries] = useState([]);
  const [pages, setPages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedPageId, setExpandedPageId] = useState(null);
  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [entriesRes, pagesRes] = await Promise.all([
        routes.fetch("seo-entries"),
        routes.fetch("page-index")
      ]);
      const entriesBody = await entriesRes.json();
      const pagesBody = await pagesRes.json();
      if (!entriesBody.ok)
        throw new Error(entriesBody.error ?? "Failed to load SEO entries");
      if (!pagesBody.ok)
        throw new Error(pagesBody.error ?? "Failed to load page index");
      setEntries(entriesBody.entries ?? []);
      setPages(pagesBody.pages ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load data");
    } finally {
      setLoading(false);
    }
  }, [routes]);
  useEffect(() => {
    load();
  }, [load]);
  const entriesByPageId = new Map;
  for (const record of entries) {
    entriesByPageId.set(record.data["page-id"], record.data);
  }
  const seen = new Set;
  const rows = [];
  for (const page of pages) {
    const pageId = page.data["page-id"];
    if (!pageId)
      continue;
    seen.add(pageId);
    rows.push({
      pageId,
      title: page.data.title ?? "",
      slug: page.data.slug ?? "",
      url: page.data.url ?? "",
      seoEntry: entriesByPageId.get(pageId) ?? null
    });
  }
  for (const record of entries) {
    const pageId = record.data["page-id"];
    if (!pageId || seen.has(pageId))
      continue;
    seen.add(pageId);
    rows.push({
      pageId,
      title: record.data["last-rendered-title"] ?? "",
      slug: "",
      url: record.data["last-rendered-url"] ?? "",
      seoEntry: record.data
    });
  }
  const totalPages = rows.length;
  const withDesc = rows.filter((r) => Boolean(r.seoEntry?.["meta-description"])).length;
  const withOg = rows.filter((r) => Boolean(r.seoEntry?.["og-image-url"])).length;
  const indexable = rows.filter((r) => !r.seoEntry?.["no-index"]).length;
  const pct = (n) => totalPages === 0 ? "—" : `${Math.round(n / totalPages * 100)}%`;
  async function handleSave(entry) {
    const res = await routes.fetch("seo-entries", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(entry)
    });
    const body = await res.json();
    if (!body.ok)
      throw new Error(body.error ?? "Save failed");
    await load();
    setExpandedPageId(null);
  }
  return /* @__PURE__ */ jsxDEV(Stack, {
    gap: 20,
    children: [
      /* @__PURE__ */ jsxDEV(Heading, {
        level: 2,
        children: "SEO Suite"
      }, undefined, false, undefined, this),
      error && /* @__PURE__ */ jsxDEV(Alert, {
        tone: "danger",
        title: "Error loading SEO data",
        children: error
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV(Stack, {
        direction: "row",
        gap: 12,
        wrap: true,
        children: [
          /* @__PURE__ */ jsxDEV(StatCard, {
            label: "Total pages",
            value: String(totalPages),
            detail: "in page index"
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV(StatCard, {
            label: "With description",
            value: pct(withDesc),
            detail: `${withDesc} of ${totalPages}`
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV(StatCard, {
            label: "With OG image",
            value: pct(withOg),
            detail: `${withOg} of ${totalPages}`
          }, undefined, false, undefined, this),
          /* @__PURE__ */ jsxDEV(StatCard, {
            label: "Indexable",
            value: pct(indexable),
            detail: `${indexable} of ${totalPages}`
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this),
      loading && /* @__PURE__ */ jsxDEV(Text, {
        variant: "muted",
        children: "Loading…"
      }, undefined, false, undefined, this),
      !loading && rows.length === 0 && /* @__PURE__ */ jsxDEV(EmptyState, {
        title: "No pages found",
        body: "Add pages in the site editor and publish them to see their SEO health here."
      }, undefined, false, undefined, this),
      !loading && rows.length > 0 && /* @__PURE__ */ jsxDEV(Stack, {
        gap: 8,
        children: [
          /* @__PURE__ */ jsxDEV(Stack, {
            direction: "row",
            gap: 8,
            align: "center",
            children: [
              /* @__PURE__ */ jsxDEV(Heading, {
                level: 3,
                children: "Pages"
              }, undefined, false, undefined, this),
              /* @__PURE__ */ jsxDEV(Button, {
                variant: "secondary",
                size: "sm",
                onClick: () => void load(),
                disabled: loading,
                children: "Refresh"
              }, undefined, false, undefined, this)
            ]
          }, undefined, true, undefined, this),
          /* @__PURE__ */ jsxDEV(Stack, {
            gap: 4,
            children: rows.map((row) => /* @__PURE__ */ jsxDEV(PageRow, {
              row,
              expanded: expandedPageId === row.pageId,
              onToggle: () => setExpandedPageId((prev) => prev === row.pageId ? null : row.pageId),
              onSave: handleSave
            }, row.pageId, false, undefined, this))
          }, undefined, false, undefined, this)
        ]
      }, undefined, true, undefined, this),
      /* @__PURE__ */ jsxDEV(Text, {
        variant: "muted",
        children: [
          "Configure global SEO defaults (site URL, OG image, robots.txt) in the",
          " ",
          /* @__PURE__ */ jsxDEV("strong", {
            children: "Settings"
          }, undefined, false, undefined, this),
          " panel on the plugin card."
        ]
      }, undefined, true, undefined, this)
    ]
  }, undefined, true, undefined, this);
}
var dashboard_default = definePluginAdminApp(SeoSuiteDashboard);
export {
  dashboard_default as default
};
